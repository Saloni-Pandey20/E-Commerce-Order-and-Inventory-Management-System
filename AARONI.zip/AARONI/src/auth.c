#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <pthread.h>
#include <crypt.h>
#include <sys/random.h>
#include "auth.h"
#include "db.h"
#include "util.h"

/* ---------- passwords ---------- */

int auth_hash(const char *password, char *out, size_t cap) {
    static const char alpha[] = "./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    unsigned char r[16];
    char salt[32] = "$6$";
    if (getrandom(r, sizeof r, 0) != (ssize_t)sizeof r) return -1;
    for (int i = 0; i < 16; i++) salt[3 + i] = alpha[r[i] % 64];
    salt[19] = '$'; salt[20] = '\0';

    struct crypt_data *d = calloc(1, sizeof *d);
    if (!d) return -1;
    char *h = crypt_r(password, salt, d);
    int rc = -1;
    if (h && h[0] == '$' && strlen(h) < cap) { strcpy(out, h); rc = 0; }
    free(d);
    return rc;
}

int auth_verify(const char *password, const char *hash) {
    if (!hash || hash[0] != '$') return 0;      /* '!' = account cannot log in */
    struct crypt_data *d = calloc(1, sizeof *d);
    if (!d) return 0;
    char *h = crypt_r(password, hash, d);
    int ok = 0;
    if (h && strlen(h) == strlen(hash)) {       /* constant-time compare */
        unsigned char diff = 0;
        for (size_t i = 0; h[i]; i++) diff |= (unsigned char)(h[i] ^ hash[i]);
        ok = (diff == 0);
    }
    free(d);
    return ok;
}

/* ---------- sessions ---------- */

#define MAX_SESSIONS 256
#define SESSION_TTL  (8 * 3600)

typedef struct { int used; char token[65]; time_t expires; SessionInfo info; } Slot;
static Slot slots[MAX_SESSIONS];
static pthread_mutex_t sess_lock = PTHREAD_MUTEX_INITIALIZER;

void session_create(const SessionInfo *info, char *token_out) {
    rand_hex(token_out, 32);
    time_t now = time(NULL);
    pthread_mutex_lock(&sess_lock);
    int pick = 0;
    for (int i = 0; i < MAX_SESSIONS; i++) {
        if (!slots[i].used || slots[i].expires < now) { pick = i; break; }
        if (slots[i].expires < slots[pick].expires) pick = i;   /* else evict oldest */
    }
    slots[pick].used = 1;
    strcpy(slots[pick].token, token_out);
    slots[pick].expires = now + SESSION_TTL;
    slots[pick].info = *info;
    pthread_mutex_unlock(&sess_lock);
}

int session_get(const char *token, SessionInfo *out) {
    if (!token || strlen(token) != 64) return 0;
    int found = 0;
    time_t now = time(NULL);
    pthread_mutex_lock(&sess_lock);
    for (int i = 0; i < MAX_SESSIONS; i++)
        if (slots[i].used && slots[i].expires >= now && strcmp(slots[i].token, token) == 0) {
            *out = slots[i].info; found = 1; break;
        }
    pthread_mutex_unlock(&sess_lock);
    return found;
}

void session_destroy(const char *token) {
    if (!token) return;
    pthread_mutex_lock(&sess_lock);
    for (int i = 0; i < MAX_SESSIONS; i++)
        if (slots[i].used && strcmp(slots[i].token, token) == 0) slots[i].used = 0;
    pthread_mutex_unlock(&sess_lock);
}

/* ---------- register / login ---------- */

static void fail(char *msg, size_t cap, const char *text) { snprintf(msg, cap, "%s", text); }

int user_register(MYSQL *c, const char *name, const char *email, const char *password,
                  SessionInfo *out, char *msg, size_t cap) {
    char em[191];
    size_t el = strlen(email);
    if (!*name || strlen(name) > 100) { fail(msg, cap, "Enter your name (max 100 characters)."); return -1; }
    if (el < 5 || el > 190 || !strchr(email, '@') || !strchr(strchr(email, '@'), '.') || strchr(email, ' ')) {
        fail(msg, cap, "Enter a valid email address."); return -1;
    }
    if (strlen(password) < 8 || strlen(password) > 72) { fail(msg, cap, "Password must be 8 to 72 characters."); return -1; }
    for (size_t i = 0; i <= el; i++) em[i] = (char)tolower((unsigned char)email[i]);

    char hash[160];
    if (auth_hash(password, hash, sizeof hash)) { fail(msg, cap, "Could not hash password."); return -1; }

    char en[512], ee[512], eh[512];
    db_escape(c, name, en, 100); db_escape(c, em, ee, 190); db_escape(c, hash, eh, 150);
    if (db_exec(c, "INSERT INTO users(name,email,password_hash,role) VALUES('%s','%s','%s','customer')", en, ee, eh)) {
        if (mysql_errno(c) == 1062) fail(msg, cap, "That email is already registered.");
        else fail(msg, cap, "Database error while registering.");
        return -1;
    }
    out->user_id = (long)mysql_insert_id(c);
    snprintf(out->role, sizeof out->role, "customer");
    snprintf(out->name, sizeof out->name, "%s", name);
    return 0;
}

int user_login(MYSQL *c, const char *email, const char *password,
               SessionInfo *out, char *msg, size_t cap) {
    char em[191], ee[512];
    size_t el = strlen(email);
    if (el == 0 || el > 190) { fail(msg, cap, "Incorrect email or password."); return -1; }
    for (size_t i = 0; i <= el; i++) em[i] = (char)tolower((unsigned char)email[i]);
    db_escape(c, em, ee, 190);

    if (db_exec(c, "SELECT id,name,password_hash,role FROM users WHERE email='%s'", ee)) {
        fail(msg, cap, "Database error while logging in."); return -1;
    }
    MYSQL_RES *res = mysql_store_result(c);
    if (!res) { fail(msg, cap, "Database error while logging in."); return -1; }
    MYSQL_ROW row = mysql_fetch_row(res);
    int ok = row && auth_verify(password, row[2]);
    if (ok) {
        out->user_id = atol(row[0]);
        snprintf(out->name, sizeof out->name, "%s", row[1]);
        snprintf(out->role, sizeof out->role, "%s", row[3]);
    }
    mysql_free_result(res);
    if (!ok) { fail(msg, cap, "Incorrect email or password."); return -1; }
    return 0;
}
