#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "order.h"
#include "db.h"
#include "transaction.h"

#define MAX_RETRIES 3

static int cmp_item(const void *a, const void *b) {
    return ((const Item *)a)->pid - ((const Item *)b)->pid;
}

int items_parse(const char *s, Item *items, int max) {
    int n = 0;
    char buf[512];
    snprintf(buf, sizeof buf, "%s", s);
    for (char *tok = strtok(buf, ","); tok; tok = strtok(NULL, ",")) {
        int pid, qty;
        char extra;
        if (sscanf(tok, "%d:%d%c", &pid, &qty, &extra) != 2) return -1;
        if (pid <= 0 || qty <= 0 || qty > 100) return -1;
        int found = 0;
        for (int i = 0; i < n; i++)
            if (items[i].pid == pid) { items[i].qty += qty; found = 1; if (items[i].qty > 100) return -1; }
        if (!found) {
            if (n >= max) return -1;
            items[n].pid = pid; items[n].qty = qty; n++;
        }
    }
    if (n == 0) return -1;
    qsort(items, (size_t)n, sizeof *items, cmp_item);
    return n;
}

static OrderResult attempt(MYSQL *c, long uid, const Item *it, int n, int *retry,
                           const char *payment_method, const char *full_name,
                           const char *phone, const char *address,
                           const char *city, const char *state, const char *pincode) {
    OrderResult r;
    memset(&r, 0, sizeof r);
    r.status = ORDER_DB_ERROR;
    char names[MAX_ITEMS][161], prices[MAX_ITEMS][24], esc[1200];
    char en[240], ep[80], ea[600], ec[160], es[160], ez[24];
    MYSQL_RES *res;
    MYSQL_ROW row;
    long oid;
    *retry = 0;

    if (txn_begin(c)) goto fail;

    /* 1. Lock every product row, in ascending id order. A concurrent buyer of the
     *    same product blocks here until we COMMIT/ROLLBACK, then sees the new stock. */
    for (int i = 0; i < n; i++) {
        if (db_exec(c, "SELECT name,price,stock FROM products WHERE id=%d AND active=1 FOR UPDATE", it[i].pid)) goto fail;
        res = mysql_store_result(c);
        if (!res) goto fail;
        row = mysql_fetch_row(res);
        if (!row) { mysql_free_result(res); txn_rollback(c); r.status = ORDER_NOT_FOUND; return r; }
        snprintf(names[i], sizeof names[i], "%s", row[0]);
        snprintf(prices[i], sizeof prices[i], "%s", row[1]);
        int stock = atoi(row[2]);
        mysql_free_result(res);
        if (stock < it[i].qty) {                 /* reject: nothing was modified */
            txn_rollback(c);
            r.status = ORDER_INSUFFICIENT;
            snprintf(r.product, sizeof r.product, "%s", names[i]);
            r.available = stock;
            return r;
        }
    }

    /* 2. Write the order, its items, delivery and payment selection atomically. */
    db_escape(c, full_name, en, 100);
    db_escape(c, phone, ep, 20);
    db_escape(c, address, ea, 250);
    db_escape(c, city, ec, 80);
    db_escape(c, state, es, 80);
    db_escape(c, pincode, ez, 6);
    if (db_exec(c, "INSERT INTO orders(user_id,total,status,payment_method,payment_status,"
                   "shipping_name,shipping_phone,shipping_address,shipping_city,shipping_state,shipping_pincode,"
                   "estimated_delivery) VALUES(%ld,0,'PLACED','%s','PENDING','%s','%s','%s','%s','%s','%s',"
                   "DATE_ADD(CURDATE(), INTERVAL 5 DAY))",
                   uid, payment_method, en, ep, ea, ec, es, ez)) goto fail;
    oid = (long)mysql_insert_id(c);
    for (int i = 0; i < n; i++) {
        db_escape(c, names[i], esc, 160);
        if (db_exec(c, "INSERT INTO order_items(order_id,product_id,product_name,unit_price,quantity) "
                       "VALUES(%ld,%d,'%s',%s,%d)", oid, it[i].pid, esc, prices[i], it[i].qty)) goto fail;
        if (db_exec(c, "UPDATE products SET stock=stock-%d WHERE id=%d", it[i].qty, it[i].pid)) goto fail;
        if (db_exec(c, "INSERT INTO inventory_movements(product_id,change_qty,reason,order_id) "
                       "VALUES(%d,%d,'ORDER',%ld)", it[i].pid, -it[i].qty, oid)) goto fail;
    }
    if (db_exec(c, "UPDATE orders SET total=(SELECT SUM(unit_price*quantity) FROM order_items WHERE order_id=%ld) "
                   "WHERE id=%ld", oid, oid)) goto fail;
    if (db_exec(c, "SELECT total FROM orders WHERE id=%ld", oid)) goto fail;
    res = mysql_store_result(c);
    if (!res) goto fail;
    row = mysql_fetch_row(res);
    snprintf(r.total, sizeof r.total, "%s", row ? row[0] : "0.00");
    mysql_free_result(res);

    if (txn_commit(c)) goto fail;
    r.status = ORDER_OK;
    r.order_id = oid;
    return r;

fail:
    *retry = txn_is_retryable(mysql_errno(c));   /* read errno BEFORE rollback */
    fprintf(stderr, "[order] db error %u: %s\n", mysql_errno(c), mysql_error(c));
    txn_rollback(c);
    r.status = ORDER_DB_ERROR;
    return r;
}

OrderResult order_place_checkout(MYSQL *c, long uid, const Item *it, int n,
                        const char *payment_method, const char *full_name,
                        const char *phone, const char *address,
                        const char *city, const char *state, const char *pincode) {
    OrderResult r;
    memset(&r, 0, sizeof r);
    if (uid <= 0 || n <= 0 || n > MAX_ITEMS ||
        (strcmp(payment_method,"COD") && strcmp(payment_method,"UPI") &&
         strcmp(payment_method,"CARD") && strcmp(payment_method,"WALLET") &&
         strcmp(payment_method,"NETBANKING")) ||
        !full_name || !*full_name || !phone || strlen(phone) < 10 ||
        !address || !*address || !city || !*city || !state || !*state ||
        !pincode || strlen(pincode) != 6 || pincode[0] < '1' || pincode[0] > '9') {
        r.status = ORDER_BAD_INPUT; return r;
    }
    for (int k = 0; k < 6; k++) {
        if (pincode[k] < '0' || pincode[k] > '9') { r.status = ORDER_BAD_INPUT; return r; }
    }
    for (int i = 0; i < MAX_RETRIES; i++) {
        int retry;
        r = attempt(c, uid, it, n, &retry, payment_method, full_name, phone,
                    address, city, state, pincode);
        if (!(r.status == ORDER_DB_ERROR && retry)) break;
        usleep(50000 * (i + 1));                 /* back off, retry the WHOLE transaction */
    }
    return r;
}

OrderResult order_place(MYSQL *c, long uid, const Item *it, int n) {
    return order_place_checkout(c, uid, it, n, "COD", "Concurrency Demo",
                                "9999999999", "Concurrency test address",
                                "Test City", "Test State", "110001");
}

void order_message(const OrderResult *r, char *out, size_t cap) {
    switch (r->status) {
    case ORDER_OK:           snprintf(out, cap, "Order #%ld placed successfully. Total Rs. %s.", r->order_id, r->total); break;
    case ORDER_INSUFFICIENT: snprintf(out, cap, "Order rejected: only %d left of \"%s\".", r->available, r->product); break;
    case ORDER_NOT_FOUND:    snprintf(out, cap, "A product in your bag is no longer available."); break;
    case ORDER_BAD_INPUT:    snprintf(out, cap, "Invalid order request."); break;
    default:                 snprintf(out, cap, "Database error; the transaction was rolled back. Please retry."); break;
    }
}

int orders_json(MYSQL *c, long uid, SB *out) {
    char where[64] = "";
    if (uid > 0) snprintf(where, sizeof where, "WHERE o.user_id=%ld", uid);
    if (db_exec(c, "SELECT o.id,o.total,o.status,o.created_at,u.name,"
                   "IFNULL(o.payment_method,'COD'),IFNULL(o.payment_status,'PENDING'),"
                   "IFNULL(o.shipping_name,''),IFNULL(o.shipping_phone,''),"
                   "IFNULL(o.shipping_address,''),IFNULL(o.shipping_city,''),"
                   "IFNULL(o.shipping_state,''),IFNULL(o.shipping_pincode,''),"
                   "IFNULL(DATE_FORMAT(o.estimated_delivery,'%%Y-%%m-%%d'),'') FROM orders o "
                   "JOIN users u ON u.id=o.user_id %s ORDER BY o.id DESC LIMIT 50", where)) return -1;
    MYSQL_RES *res = mysql_store_result(c);
    if (!res) return -1;
    sb_cat(out, "{\"orders\":[");
    MYSQL_ROW row; int first = 1;
    while ((row = mysql_fetch_row(res))) {
        sb_catf(out, "%s{\"id\":%s,\"total\":%s,\"status\":\"%s\",\"created\":\"%s\",\"customer\":",
                first ? "" : ",", row[0], row[1], row[2], row[3]);
        sb_json(out, row[4]);
        sb_cat(out, ",\"payment_method\":"); sb_json(out, row[5]);
        sb_cat(out, ",\"payment_status\":"); sb_json(out, row[6]);
        sb_cat(out, ",\"shipping_name\":"); sb_json(out, row[7]);
        sb_cat(out, ",\"shipping_phone\":"); sb_json(out, row[8]);
        sb_cat(out, ",\"shipping_address\":"); sb_json(out, row[9]);
        sb_cat(out, ",\"shipping_city\":"); sb_json(out, row[10]);
        sb_cat(out, ",\"shipping_state\":"); sb_json(out, row[11]);
        sb_cat(out, ",\"shipping_pincode\":"); sb_json(out, row[12]);
        sb_cat(out, ",\"estimated_delivery\":"); sb_json(out, row[13]);
        sb_cat(out, ",\"items\":[");
        first = 0;
        if (db_exec(c, "SELECT product_name,quantity,unit_price FROM order_items WHERE order_id=%s ORDER BY id", row[0]) == 0) {
            MYSQL_RES *ir = mysql_store_result(c);
            if (ir) {
                MYSQL_ROW irow; int f2 = 1;
                while ((irow = mysql_fetch_row(ir))) {
                    sb_catf(out, "%s{\"name\":", f2 ? "" : ",");
                    sb_json(out, irow[0]);
                    sb_catf(out, ",\"qty\":%s,\"price\":%s}", irow[1], irow[2]);
                    f2 = 0;
                }
                mysql_free_result(ir);
            }
        }
        sb_cat(out, "]}");
    }
    sb_cat(out, "]}");
    mysql_free_result(res);
    return 0;
}

int order_cancel(MYSQL *c, long uid, long oid, char *msg, size_t cap) {
    MYSQL_RES *res;
    MYSQL_ROW row;
    char status[24];
    if (txn_begin(c)) { snprintf(msg, cap, "Database error."); return -1; }
    if (db_exec(c, "SELECT status FROM orders WHERE id=%ld AND user_id=%ld FOR UPDATE", oid, uid)) goto fail;
    res = mysql_store_result(c);
    if (!res) goto fail;
    row = mysql_fetch_row(res);
    if (!row) { mysql_free_result(res); txn_rollback(c); snprintf(msg, cap, "Order not found."); return -1; }
    snprintf(status, sizeof status, "%s", row[0]);
    mysql_free_result(res);
    if (strcmp(status, "PLACED") && strcmp(status, "PROCESSING")) {
        txn_rollback(c);
        snprintf(msg, cap, "This order can no longer be cancelled (status %s).", status);
        return -1;
    }
    /* Restore stock in ascending product id (same lock order as checkout). */
    if (db_exec(c, "SELECT product_id,quantity FROM order_items WHERE order_id=%ld ORDER BY product_id", oid)) goto fail;
    res = mysql_store_result(c);
    if (!res) goto fail;
    while ((row = mysql_fetch_row(res))) {
        if (db_exec(c, "UPDATE products SET stock=stock+%s WHERE id=%s", row[1], row[0]) ||
            db_exec(c, "INSERT INTO inventory_movements(product_id,change_qty,reason,order_id) VALUES(%s,%s,'CANCEL',%ld)",
                    row[0], row[1], oid)) { mysql_free_result(res); goto fail; }
    }
    mysql_free_result(res);
    if (db_exec(c, "UPDATE orders SET status='CANCELLED' WHERE id=%ld", oid)) goto fail;
    if (txn_commit(c)) goto fail;
    snprintf(msg, cap, "Order #%ld cancelled and stock restored.", oid);
    return 0;
fail:
    txn_rollback(c);
    snprintf(msg, cap, "Database error while cancelling; nothing was changed.");
    return -1;
}

int admin_order_status(MYSQL *c, long oid, const char *status, char *msg, size_t cap) {
    if (strcmp(status, "PROCESSING") && strcmp(status, "SHIPPED") && strcmp(status, "DELIVERED")) {
        snprintf(msg, cap, "Invalid status."); return -1;
    }
    if (db_exec(c, "UPDATE orders SET status='%s' WHERE id=%ld AND status<>'CANCELLED'", status, oid)) {
        snprintf(msg, cap, "Database error."); return -1;
    }
    if (mysql_affected_rows(c) == 0) {
        snprintf(msg, cap, "Nothing changed (order is cancelled, already in that status, or not found).");
        return -1;
    }
    snprintf(msg, cap, "Order #%ld is now %s.", oid, status);
    return 0;
}
