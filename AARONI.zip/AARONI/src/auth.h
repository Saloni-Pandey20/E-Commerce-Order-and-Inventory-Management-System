#ifndef AUTH_H
#define AUTH_H

#include <stddef.h>
#include <mysql/mysql.h>

typedef struct { long user_id; char role[16]; char name[101]; } SessionInfo;

/* Password hashing: glibc crypt_r with SHA-512 and a random salt. */
int  auth_hash(const char *password, char *out, size_t cap);   /* 0 ok */
int  auth_verify(const char *password, const char *hash);      /* 1 match */

/* In-memory session table (mutex protected). Token is 64 hex chars. */
void session_create(const SessionInfo *info, char *token_out /* >=65 */);
int  session_get(const char *token, SessionInfo *out);         /* 1 if valid */
void session_destroy(const char *token);

/* Both return 0 on success; on failure msg explains why. */
int  user_register(MYSQL *c, const char *name, const char *email, const char *password,
                   SessionInfo *out, char *msg, size_t cap);
int  user_login(MYSQL *c, const char *email, const char *password,
                SessionInfo *out, char *msg, size_t cap);

#endif
