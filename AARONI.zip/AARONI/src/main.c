#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <mysql/mysql.h>
#include "http.h"

int main(int argc, char **argv) {
    int port = argc > 1 ? atoi(argv[1]) : 8080;
    const char *web_root = argc > 2 ? argv[2] : "frontend";

    signal(SIGPIPE, SIG_IGN);
    if (mysql_library_init(0, NULL, NULL)) {
        fprintf(stderr, "could not initialise the MySQL client library\n");
        return 1;
    }
    int rc = http_serve(port, web_root);
    mysql_library_end();
    return rc == 0 ? 0 : 1;
}
