#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <ctype.h>
#include <sys/random.h>
#include "util.h"

static void sb_reserve(SB *s, size_t extra) {
    if (s->len + extra + 1 <= s->cap) return;
    size_t nc = s->cap ? s->cap : 256;
    while (nc < s->len + extra + 1) nc *= 2;
    char *np = realloc(s->p, nc);
    if (!np) { fprintf(stderr, "out of memory\n"); abort(); }
    s->p = np; s->cap = nc;
}

void sb_init(SB *s) { s->p = NULL; s->len = s->cap = 0; sb_reserve(s, 0); s->p[0] = '\0'; }
void sb_free(SB *s) { free(s->p); s->p = NULL; s->len = s->cap = 0; }

void sb_cat(SB *s, const char *str) {
    size_t n = strlen(str);
    sb_reserve(s, n);
    memcpy(s->p + s->len, str, n + 1);
    s->len += n;
}

void sb_catf(SB *s, const char *fmt, ...) {
    va_list ap, ap2;
    va_start(ap, fmt);
    va_copy(ap2, ap);
    int n = vsnprintf(NULL, 0, fmt, ap);
    va_end(ap);
    if (n > 0) {
        sb_reserve(s, (size_t)n);
        vsnprintf(s->p + s->len, (size_t)n + 1, fmt, ap2);
        s->len += (size_t)n;
    }
    va_end(ap2);
}

void sb_json(SB *s, const char *str) {
    sb_cat(s, "\"");
    for (const unsigned char *c = (const unsigned char *)str; *c; c++) {
        if (*c == '"' || *c == '\\') { char t[3] = { '\\', (char)*c, 0 }; sb_cat(s, t); }
        else if (*c < 0x20)          { sb_catf(s, "\\u%04x", *c); }
        else                         { char t[2] = { (char)*c, 0 }; sb_cat(s, t); }
    }
    sb_cat(s, "\"");
}

int form_get(const char *form, const char *key, char *out, size_t cap) {
    if (!form || !cap) return 0;
    size_t klen = strlen(key);
    const char *p = form;
    while (p && *p) {
        if (strncmp(p, key, klen) == 0 && p[klen] == '=') {
            p += klen + 1;
            size_t i = 0;
            while (*p && *p != '&' && i + 1 < cap) {
                if (*p == '%' && isxdigit((unsigned char)p[1]) && isxdigit((unsigned char)p[2])) {
                    char hex[3] = { p[1], p[2], 0 };
                    out[i++] = (char)strtol(hex, NULL, 16);
                    p += 3;
                } else if (*p == '+') { out[i++] = ' '; p++; }
                else out[i++] = *p++;
            }
            out[i] = '\0';
            return 1;
        }
        p = strchr(p, '&');
        if (p) p++;
    }
    return 0;
}

void rand_hex(char *out, size_t nbytes) {
    unsigned char buf[64];
    if (nbytes > sizeof buf) nbytes = sizeof buf;
    if (getrandom(buf, nbytes, 0) != (ssize_t)nbytes) { fprintf(stderr, "getrandom failed\n"); abort(); }
    for (size_t i = 0; i < nbytes; i++) sprintf(out + 2 * i, "%02x", buf[i]);
}

void slugify(const char *in, char *out, size_t cap) {
    size_t j = 0; int dash = 0;
    for (size_t i = 0; in[i] && j + 1 < cap; i++) {
        unsigned char c = (unsigned char)in[i];
        if (isalnum(c)) { out[j++] = (char)tolower(c); dash = 0; }
        else if (!dash && j > 0) { out[j++] = '-'; dash = 1; }
    }
    while (j > 0 && out[j - 1] == '-') j--;
    out[j] = '\0';
}
