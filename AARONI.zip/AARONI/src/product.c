#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "product.h"
#include "db.h"
#include "transaction.h"

static const char *nz(const char *s) { return s ? s : ""; }

int products_json(MYSQL *c, const char *q, int cat, const char *min, const char *max,
                  const char *sort, SB *out) {
    SB sql; sb_init(&sql);
    sb_cat(&sql, "SELECT p.id,p.name,p.description,p.price,p.image_url,p.stock,p.sku,IFNULL(c.name,'') "
                 "FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.active=1");
    if (q && *q) {
        char esc[512];
        db_escape(c, q, esc, 100);
        sb_catf(&sql, " AND (p.name LIKE '%%%s%%' OR p.description LIKE '%%%s%%' OR c.name LIKE '%%%s%%')",
                esc, esc, esc);
    }
    if (cat > 0) sb_catf(&sql, " AND p.category_id=%d", cat);
    char *end;
    if (min && *min) { double v = strtod(min, &end); if (*end == '\0' && v >= 0) sb_catf(&sql, " AND p.price>=%.2f", v); }
    if (max && *max) { double v = strtod(max, &end); if (*end == '\0' && v >= 0) sb_catf(&sql, " AND p.price<=%.2f", v); }

    const char *order = "p.id DESC";
    if (sort && !strcmp(sort, "price_low"))  order = "p.price ASC, p.id";
    if (sort && !strcmp(sort, "price_high")) order = "p.price DESC, p.id";
    if (sort && !strcmp(sort, "name"))       order = "p.name ASC";
    sb_catf(&sql, " ORDER BY %s LIMIT 200", order);

    int rc = db_exec(c, "%s", sql.p);
    sb_free(&sql);
    if (rc) return -1;
    MYSQL_RES *res = mysql_store_result(c);
    if (!res) return -1;

    sb_cat(out, "{\"products\":[");
    MYSQL_ROW row; int first = 1;
    while ((row = mysql_fetch_row(res))) {
        if (!first) sb_cat(out, ",");
        first = 0;
        sb_catf(out, "{\"id\":%s,\"name\":", row[0]);          sb_json(out, nz(row[1]));
        sb_cat(out, ",\"description\":");                      sb_json(out, nz(row[2]));
        sb_catf(out, ",\"price\":%s,\"image_url\":", row[3]);  sb_json(out, nz(row[4]));
        sb_catf(out, ",\"stock\":%s,\"sku\":", row[5]);        sb_json(out, nz(row[6]));
        sb_cat(out, ",\"category\":");                         sb_json(out, nz(row[7]));
        sb_cat(out, "}");
    }
    sb_cat(out, "]}");
    mysql_free_result(res);
    return 0;
}

int categories_json(MYSQL *c, SB *out) {
    if (db_exec(c, "SELECT id,name FROM categories ORDER BY name")) return -1;
    MYSQL_RES *res = mysql_store_result(c);
    if (!res) return -1;
    sb_cat(out, "{\"categories\":[");
    MYSQL_ROW row; int first = 1;
    while ((row = mysql_fetch_row(res))) {
        sb_catf(out, "%s{\"id\":%s,\"name\":", first ? "" : ",", row[0]);
        sb_json(out, nz(row[1]));
        sb_cat(out, "}");
        first = 0;
    }
    sb_cat(out, "]}");
    mysql_free_result(res);
    return 0;
}

int admin_add_category(MYSQL *c, const char *name, char *msg, size_t cap) {
    char slug[128], en[256], es[256];
    if (!*name || strlen(name) > 80) { snprintf(msg, cap, "Enter a category name (max 80 characters)."); return -1; }
    slugify(name, slug, sizeof slug);
    if (!*slug) { snprintf(msg, cap, "Category name needs letters or digits."); return -1; }
    db_escape(c, name, en, 80); db_escape(c, slug, es, 100);
    if (db_exec(c, "INSERT INTO categories(name,slug) VALUES('%s','%s')", en, es)) {
        if (mysql_errno(c) == 1062) snprintf(msg, cap, "That category already exists.");
        else snprintf(msg, cap, "Database error while adding category.");
        return -1;
    }
    snprintf(msg, cap, "Category added.");
    return 0;
}

int admin_add_product(MYSQL *c, const char *name, const char *sku, int cat, const char *price,
                      int stock, const char *image, const char *desc, char *msg, size_t cap) {
    char *end;
    double pv = strtod(price, &end);
    if (!*name || strlen(name) > 160) { snprintf(msg, cap, "Enter a product name (max 160 characters)."); return -1; }
    if (*price == '\0' || *end != '\0' || pv < 0 || pv > 9999999) { snprintf(msg, cap, "Enter a valid price."); return -1; }
    if (stock < 0 || stock > 1000000) { snprintf(msg, cap, "Enter a valid stock (0 or more)."); return -1; }

    char en[400], es[120], ei[1100], ed[1100], cat_sql[24], sku_sql[140];
    db_escape(c, name, en, 160); db_escape(c, image, ei, 500); db_escape(c, desc, ed, 500);
    if (cat > 0) snprintf(cat_sql, sizeof cat_sql, "%d", cat); else snprintf(cat_sql, sizeof cat_sql, "NULL");
    if (*sku) { db_escape(c, sku, es, 50); snprintf(sku_sql, sizeof sku_sql, "'%s'", es); }
    else snprintf(sku_sql, sizeof sku_sql, "NULL");

    if (txn_begin(c)) { snprintf(msg, cap, "Database error."); return -1; }
    if (db_exec(c, "INSERT INTO products(category_id,name,description,price,image_url,stock,sku) "
                   "VALUES(%s,'%s','%s',%.2f,'%s',%d,%s)", cat_sql, en, ed, pv, ei, stock, sku_sql)) {
        int dup = mysql_errno(c) == 1062, fk = mysql_errno(c) == 1452;
        txn_rollback(c);
        snprintf(msg, cap, dup ? "That SKU already exists." : fk ? "That category does not exist." : "Database error while adding product.");
        return -1;
    }
    long pid = (long)mysql_insert_id(c);
    if (stock > 0 && db_exec(c, "INSERT INTO inventory_movements(product_id,change_qty,reason) VALUES(%ld,%d,'INITIAL')", pid, stock)) {
        txn_rollback(c); snprintf(msg, cap, "Database error."); return -1;
    }
    if (txn_commit(c)) { snprintf(msg, cap, "Database error."); return -1; }
    snprintf(msg, cap, "Product added.");
    return 0;
}

int admin_set_stock(MYSQL *c, int pid, int stock, const char *reason, char *msg, size_t cap) {
    if (pid <= 0 || stock < 0 || stock > 1000000) { snprintf(msg, cap, "Invalid product or stock."); return -1; }
    char er[100];
    db_escape(c, reason, er, 50);
    if (txn_begin(c)) { snprintf(msg, cap, "Database error."); return -1; }
    if (db_exec(c, "SELECT stock FROM products WHERE id=%d FOR UPDATE", pid)) goto fail;
    MYSQL_RES *res = mysql_store_result(c);
    if (!res) goto fail;
    MYSQL_ROW row = mysql_fetch_row(res);
    if (!row) { mysql_free_result(res); txn_rollback(c); snprintf(msg, cap, "Product not found."); return -1; }
    int old = atoi(row[0]);
    mysql_free_result(res);
    if (db_exec(c, "UPDATE products SET stock=%d WHERE id=%d", stock, pid)) goto fail;
    if (stock != old &&
        db_exec(c, "INSERT INTO inventory_movements(product_id,change_qty,reason) VALUES(%d,%d,'%s')", pid, stock - old, er)) goto fail;
    if (txn_commit(c)) goto fail;
    snprintf(msg, cap, "Stock updated.");
    return 0;
fail:
    txn_rollback(c);
    snprintf(msg, cap, "Database error while updating stock.");
    return -1;
}
