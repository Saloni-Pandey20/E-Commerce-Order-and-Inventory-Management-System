#include "transaction.h"

int txn_begin(MYSQL *c)    { return mysql_query(c, "START TRANSACTION") ? -1 : 0; }
int txn_commit(MYSQL *c)   { return mysql_query(c, "COMMIT") ? -1 : 0; }
int txn_rollback(MYSQL *c) { return mysql_query(c, "ROLLBACK") ? -1 : 0; }

int txn_is_retryable(unsigned e) { return e == 1213 || e == 1205; }
