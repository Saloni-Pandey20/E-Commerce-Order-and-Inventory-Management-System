#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include "db.h"

static const char *env_or(const char *name, const char *def) {
    const char *v = getenv(name);
    return (v && *v) ? v : def;
}

MYSQL *db_connect(void) {
    MYSQL *c = mysql_init(NULL);
    if (!c) return NULL;
    unsigned port = (unsigned)atoi(env_or("ECOM_DB_PORT", "3306"));
    if (!mysql_real_connect(c, env_or("ECOM_DB_HOST", "127.0.0.1"),
                            env_or("ECOM_DB_USER", "ecom"),
                            env_or("ECOM_DB_PASS", "ecom_pass"),
                            env_or("ECOM_DB_NAME", "aaroni_c"), port, NULL, 0)) {
        fprintf(stderr, "[db] connect failed: %s\n", mysql_error(c));
        mysql_close(c);
        return NULL;
    }
    mysql_set_character_set(c, "utf8mb4");
    return c;
}

int db_exec(MYSQL *c, const char *fmt, ...) {
    char q[8192];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(q, sizeof q, fmt, ap);
    va_end(ap);
    if (n < 0 || (size_t)n >= sizeof q) { fprintf(stderr, "[db] query too long\n"); return -1; }
    return mysql_query(c, q) ? -1 : 0;
}

void db_escape(MYSQL *c, const char *in, char *out, size_t maxlen) {
    size_t len = strlen(in);
    if (len > maxlen) len = maxlen;
    mysql_real_escape_string(c, out, in, (unsigned long)len);
}
