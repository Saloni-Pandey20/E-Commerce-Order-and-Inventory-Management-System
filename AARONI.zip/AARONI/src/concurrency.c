#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include "concurrency.h"
#include "db.h"
#include "order.h"
#include "product.h"
#include "sync.h"

typedef struct {
    long uid;
    int pid, qty;
    pthread_barrier_t *bar;
    OrderResult res;
} RaceArg;

static void *race_thread(void *p) {
    RaceArg *a = p;
    a->res.status = ORDER_DB_ERROR;
    MYSQL *c = db_connect();                 /* own connection per thread */
    pthread_barrier_wait(a->bar);            /* both threads are released together */
    if (c) {
        Item it = { a->pid, a->qty };
        a->res = order_place(c, a->uid, &it, 1);
        mysql_close(c);
    }
    mysql_thread_end();
    return NULL;
}

static long demo_user(MYSQL *c, const char *email) {
    long id = 0;
    if (db_exec(c, "SELECT id FROM users WHERE email='%s'", email)) return 0;
    MYSQL_RES *r = mysql_store_result(c);
    if (!r) return 0;
    MYSQL_ROW row = mysql_fetch_row(r);
    if (row) id = atol(row[0]);
    mysql_free_result(r);
    return id;
}

int race_run(MYSQL *c, int pid, int stock, int qty, SB *out, char *msg, size_t cap) {
    if (pid <= 0 || stock < 0 || qty < 1 || qty > 100) { snprintf(msg, cap, "Invalid demo settings."); return -1; }
    long ua = demo_user(c, "demo_a@shop.local"), ub = demo_user(c, "demo_b@shop.local");
    if (!ua || !ub) { snprintf(msg, cap, "Demo customers missing. Re-run database/sample_data.sql."); return -1; }
    if (admin_set_stock(c, pid, stock, "DEMO RESET", msg, cap)) return -1;

    pthread_barrier_t bar;
    pthread_barrier_init(&bar, NULL, 2);
    RaceArg args[2] = { { ua, pid, qty, &bar, {0} }, { ub, pid, qty, &bar, {0} } };
    pthread_t th[2];
    for (int i = 0; i < 2; i++)
        if (pthread_create(&th[i], NULL, race_thread, &args[i])) { snprintf(msg, cap, "Could not start threads."); return -1; }
    for (int i = 0; i < 2; i++) pthread_join(th[i], NULL);
    pthread_barrier_destroy(&bar);

    int final_stock = -1;
    if (db_exec(c, "SELECT stock FROM products WHERE id=%d", pid) == 0) {
        MYSQL_RES *r = mysql_store_result(c);
        if (r) { MYSQL_ROW row = mysql_fetch_row(r); if (row) final_stock = atoi(row[0]); mysql_free_result(r); }
    }
    int succeeded = 0;
    sb_catf(out, "{\"success\":true,\"initial_stock\":%d,\"quantity_each\":%d,\"results\":[", stock, qty);
    for (int i = 0; i < 2; i++) {
        char m[300];
        order_message(&args[i].res, m, sizeof m);
        int ok = args[i].res.status == ORDER_OK;
        succeeded += ok;
        sync_stats_record(ok, args[i].res.status == ORDER_INSUFFICIENT, args[i].res.status == ORDER_DB_ERROR);
        sb_catf(out, "%s{\"customer\":\"Customer %c\",\"success\":%s,\"message\":", i ? "," : "", 'A' + i, ok ? "true" : "false");
        sb_json(out, m);
        sb_cat(out, "}");
    }
    sb_catf(out, "],\"orders_succeeded\":%d,\"final_stock\":%d,\"never_negative\":%s}",
            succeeded, final_stock, final_stock >= 0 ? "true" : "false");
    return 0;
}

int consistency_json(MYSQL *c, SB *out) {
    if (db_exec(c, "SELECT p.id,p.name,p.stock,IFNULL(SUM(m.change_qty),0) FROM products p "
                   "LEFT JOIN inventory_movements m ON m.product_id=p.id "
                   "GROUP BY p.id,p.name,p.stock HAVING p.stock<>IFNULL(SUM(m.change_qty),0)")) return -1;
    MYSQL_RES *r = mysql_store_result(c);
    if (!r) return -1;
    unsigned long bad = (unsigned long)mysql_num_rows(r);
    sb_catf(out, "{\"consistent\":%s,\"mismatches\":[", bad == 0 ? "true" : "false");
    MYSQL_ROW row; int first = 1;
    while ((row = mysql_fetch_row(r))) {
        sb_catf(out, "%s{\"id\":%s,\"name\":", first ? "" : ",", row[0]);
        sb_json(out, row[1]);
        sb_catf(out, ",\"stock\":%s,\"expected\":%s}", row[2], row[3]);
        first = 0;
    }
    sb_cat(out, "]}");
    mysql_free_result(r);
    return 0;
}
