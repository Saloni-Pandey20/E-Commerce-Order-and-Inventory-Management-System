#ifndef TRANSACTION_H
#define TRANSACTION_H

#include <mysql/mysql.h>

/* Thin wrappers over MySQL transactions. 0 = ok, -1 = error. */
int txn_begin(MYSQL *c);
int txn_commit(MYSQL *c);
int txn_rollback(MYSQL *c);

/* 1 if the whole transaction may safely be retried:
 * 1213 = deadlock (InnoDB rolled this transaction back), 1205 = lock wait timeout */
int txn_is_retryable(unsigned mysql_errno);

#endif
