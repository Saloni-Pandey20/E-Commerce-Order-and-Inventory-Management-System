#include <pthread.h>
#include "sync.h"

static pthread_mutex_t stats_lock = PTHREAD_MUTEX_INITIALIZER;
static Stats stats;
static sem_t worker_slots;

void sync_init(int max_workers) { sem_init(&worker_slots, 0, (unsigned)max_workers); }

void sync_stats_record(int ok, int rejected, int error) {
    pthread_mutex_lock(&stats_lock);      /* --- critical section --- */
    stats.orders_ok       += ok;
    stats.orders_rejected += rejected;
    stats.orders_error    += error;
    pthread_mutex_unlock(&stats_lock);    /* --- end critical section --- */
}

void sync_stats_get(Stats *out) {
    pthread_mutex_lock(&stats_lock);
    *out = stats;
    pthread_mutex_unlock(&stats_lock);
}

void sync_worker_acquire(void) { while (sem_wait(&worker_slots) != 0) { /* retry on EINTR */ } }
void sync_worker_release(void) { sem_post(&worker_slots); }
