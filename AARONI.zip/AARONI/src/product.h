#ifndef PRODUCT_H
#define PRODUCT_H

#include <mysql/mysql.h>
#include "util.h"

/* JSON: {"products":[...]}. Filters are optional (empty string / 0 = no filter).
 * sort: price_low | price_high | name | new (default). 0 ok, -1 DB error. */
int products_json(MYSQL *c, const char *q, int category_id, const char *min,
                  const char *max, const char *sort, SB *out);
int categories_json(MYSQL *c, SB *out);

/* Admin operations. 0 ok, -1 failure (msg explains). */
int admin_add_category(MYSQL *c, const char *name, char *msg, size_t cap);
int admin_add_product(MYSQL *c, const char *name, const char *sku, int category_id,
                      const char *price, int stock, const char *image_url,
                      const char *description, char *msg, size_t cap);
int admin_set_stock(MYSQL *c, int product_id, int stock, const char *reason,
                    char *msg, size_t cap);

#endif
