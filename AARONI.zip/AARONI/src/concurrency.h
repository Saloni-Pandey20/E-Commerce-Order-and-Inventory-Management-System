#ifndef CONCURRENCY_H
#define CONCURRENCY_H

#include <mysql/mysql.h>
#include "util.h"

/* Demo: set product stock, then start TWO threads, each with its own MySQL
 * connection, released by a barrier so both place an order for `qty` units at
 * the same instant. Returns the outcome as JSON. 0 ok, -1 failure (msg). */
int race_run(MYSQL *c, int product_id, int stock, int qty, SB *out, char *msg, size_t cap);

/* Consistency check: for every product, stock must equal the sum of its
 * inventory_movements. Returns JSON with any mismatches. */
int consistency_json(MYSQL *c, SB *out);

#endif
