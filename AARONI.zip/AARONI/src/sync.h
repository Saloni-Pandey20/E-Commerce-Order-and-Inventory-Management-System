#ifndef SYNC_H
#define SYNC_H

#include <semaphore.h>

/* Shared statistics, protected by a pthread mutex (critical section).
 * NOTE: this mutex is NOT what prevents overselling; MySQL row locks do. */
typedef struct { long orders_ok, orders_rejected, orders_error; } Stats;

void sync_init(int max_workers);
void sync_stats_record(int ok, int rejected, int error);
void sync_stats_get(Stats *out);

/* Resource management: counting semaphore bounds worker threads (and DB connections). */
void sync_worker_acquire(void);
void sync_worker_release(void);

#endif
