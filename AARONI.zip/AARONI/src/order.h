#ifndef ORDER_H
#define ORDER_H

#include <mysql/mysql.h>
#include "util.h"

#define MAX_ITEMS 20

typedef struct { int pid; int qty; } Item;

typedef enum {
    ORDER_OK = 0, ORDER_INSUFFICIENT, ORDER_NOT_FOUND, ORDER_BAD_INPUT, ORDER_DB_ERROR
} OrderStatus;

typedef struct {
    OrderStatus status;
    long  order_id;      /* ORDER_OK */
    char  total[32];     /* ORDER_OK */
    char  product[161];  /* ORDER_INSUFFICIENT: the product that was short */
    int   available;     /* ORDER_INSUFFICIENT: stock seen under lock */
} OrderResult;

/* Parse "pid:qty,pid:qty". Merges duplicates and sorts by pid (fixed lock order
 * for every transaction, which prevents deadlocks). Returns count or -1. */
int items_parse(const char *s, Item *items, int max);

/* One ACID transaction: lock rows (SELECT ... FOR UPDATE), check stock, insert
 * order + items, decrement stock, log movements, COMMIT. Any failure: ROLLBACK.
 * Deadlocks and lock timeouts are retried. */
OrderResult order_place(MYSQL *c, long user_id, const Item *items, int n);
OrderResult order_place_checkout(MYSQL *c, long user_id, const Item *items, int n,
                                 const char *payment_method, const char *full_name,
                                 const char *phone, const char *address,
                                 const char *city, const char *state,
                                 const char *pincode);
void order_message(const OrderResult *r, char *out, size_t cap);

int orders_json(MYSQL *c, long user_id /* 0 = all orders (admin) */, SB *out);
int order_cancel(MYSQL *c, long user_id, long order_id, char *msg, size_t cap);
int admin_order_status(MYSQL *c, long order_id, const char *status, char *msg, size_t cap);

#endif
