#ifndef DB_H
#define DB_H

#include <stddef.h>
#include <mysql/mysql.h>

/* Open a connection (settings from env: ECOM_DB_HOST/PORT/USER/PASS/NAME).
 * Each worker thread uses its OWN connection (MYSQL* is not thread-safe). */
MYSQL *db_connect(void);

/* printf-style query. Returns 0 on success, -1 on error (see mysql_error). */
int db_exec(MYSQL *c, const char *fmt, ...) __attribute__((format(printf, 2, 3)));

/* Escape at most maxlen bytes of `in` into out (out needs 2*maxlen+1). */
void db_escape(MYSQL *c, const char *in, char *out, size_t maxlen);

#endif
