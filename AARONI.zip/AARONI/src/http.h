#ifndef HTTP_H
#define HTTP_H

/* Blocking HTTP server: one pthread per connection (bounded by a semaphore).
 * Serves the frontend files from web_root and the JSON API under /api. */
int http_serve(int port, const char *web_root);

#endif
