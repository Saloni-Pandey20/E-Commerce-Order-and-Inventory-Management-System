#ifndef UTIL_H
#define UTIL_H

#include <stddef.h>

/* Growable string buffer used to build JSON responses. */
typedef struct { char *p; size_t len, cap; } SB;

void sb_init(SB *s);
void sb_free(SB *s);
void sb_cat(SB *s, const char *str);
void sb_catf(SB *s, const char *fmt, ...) __attribute__((format(printf, 2, 3)));
void sb_json(SB *s, const char *str);          /* appends "escaped string" */

/* Read key from "a=b&c=d" (URL-decoded). Returns 1 if found. */
int  form_get(const char *form, const char *key, char *out, size_t cap);

void rand_hex(char *out, size_t nbytes);       /* out needs 2*nbytes+1 */
void slugify(const char *in, char *out, size_t cap);

#endif
