#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include "http.h"
#include "db.h"
#include "util.h"
#include "auth.h"
#include "product.h"
#include "order.h"
#include "concurrency.h"
#include "sync.h"

#define MAX_WORKERS 32
#define REQ_MAX 16384

static const char *g_web_root;

typedef struct {
    char method[8];
    char path[256];
    const char *query;
    const char *body;
    char sid[80];
} Req;

/* ---------- response helpers ---------- */

static void send_all(int fd, const char *p, size_t n) {
    while (n) {
        ssize_t w = send(fd, p, n, MSG_NOSIGNAL);
        if (w <= 0) return;
        p += w; n -= (size_t)w;
    }
}

static const char *reason(int code) {
    switch (code) {
    case 200: return "OK";           case 400: return "Bad Request";
    case 401: return "Unauthorized"; case 403: return "Forbidden";
    case 404: return "Not Found";    case 405: return "Method Not Allowed";
    default:  return "Internal Server Error";
    }
}

static void respond(int fd, int code, const char *ctype, const char *body, size_t len, const char *extra) {
    char h[512];
    int n = snprintf(h, sizeof h,
        "HTTP/1.1 %d %s\r\nContent-Type: %s\r\nContent-Length: %zu\r\n"
        "Cache-Control: no-store\r\n%sConnection: close\r\n\r\n",
        code, reason(code), ctype, len, extra ? extra : "");
    send_all(fd, h, (size_t)n);
    send_all(fd, body, len);
}

static void send_json(int fd, int code, const char *json, const char *extra) {
    respond(fd, code, "application/json", json, strlen(json), extra);
}

static void send_sb(int fd, int code, SB *sb) { respond(fd, code, "application/json", sb->p, sb->len, NULL); }

static void send_msg(int fd, int code, int success, const char *msg) {
    SB sb; sb_init(&sb);
    sb_catf(&sb, "{\"success\":%s,\"message\":", success ? "true" : "false");
    sb_json(&sb, msg);
    sb_cat(&sb, "}");
    send_sb(fd, code, &sb);
    sb_free(&sb);
}

static void serve_static(int fd, const char *name, const char *ctype) {
    char path[600];
    snprintf(path, sizeof path, "%s/%s", g_web_root, name);
    FILE *f = fopen(path, "rb");
    if (!f) { send_msg(fd, 404, 0, "File not found."); return; }
    fseek(f, 0, SEEK_END); long sz = ftell(f); rewind(f);
    char *buf = malloc((size_t)sz + 1);
    size_t rd = buf ? fread(buf, 1, (size_t)sz, f) : 0;
    fclose(f);
    if (buf) respond(fd, 200, ctype, buf, rd, NULL);
    free(buf);
}

/* ---------- request parsing ---------- */

static int param(const Req *r, const char *key, char *out, size_t cap) {
    out[0] = '\0';
    if (form_get(r->body, key, out, cap)) return 1;
    return form_get(r->query, key, out, cap);
}

static void parse_cookie(const char *buf, char *sid, size_t cap) {
    sid[0] = '\0';
    const char *h = strcasestr(buf, "\r\nCookie:");
    if (!h) return;
    const char *end = strstr(h + 2, "\r\n");
    const char *p = strstr(h, "sid=");
    if (!p || (end && p > end)) return;
    p += 4;
    size_t i = 0;
    while (*p && *p != ';' && *p != '\r' && i + 1 < cap) sid[i++] = *p++;
    sid[i] = '\0';
}

/* ---------- API ---------- */

typedef struct { MYSQL *db; int tried; } Lazy;

static MYSQL *get_db(Lazy *l) {
    if (!l->tried) { l->db = db_connect(); l->tried = 1; }
    return l->db;
}

static void cookie_header(char *out, size_t cap, const char *token) {
    snprintf(out, cap, "Set-Cookie: sid=%s; Path=/; HttpOnly; SameSite=Lax\r\n", token);
}

static void session_json(SB *sb, const SessionInfo *me) {
    sb_cat(sb, "{\"success\":true,\"user\":{\"name\":");
    sb_json(sb, me->name);
    sb_catf(sb, ",\"role\":\"%s\",\"id\":%ld}}", me->role, me->user_id);
}

static void handle_api(int fd, const Req *rq) {
    Lazy lz = { NULL, 0 };
    SessionInfo me;
    int logged = session_get(rq->sid, &me);
    int is_post = strcmp(rq->method, "POST") == 0;
    int is_get = strcmp(rq->method, "GET") == 0;
    const char *p = rq->path;
    char a[512], b[512], c2[512], d[512], e[512], f[600], g[600];
    char msg[300];
    MYSQL *db;

#define NEED_DB() do { db = get_db(&lz); if (!db) { send_msg(fd, 500, 0, "Cannot connect to the database."); goto done; } } while (0)
#define NEED_POST() do { if (!is_post) { send_msg(fd, 405, 0, "Use POST."); goto done; } } while (0)
#define NEED_LOGIN() do { if (!logged) { send_msg(fd, 401, 0, "Please log in first."); goto done; } } while (0)
#define NEED_ADMIN() do { NEED_LOGIN(); if (strcmp(me.role, "admin")) { send_msg(fd, 403, 0, "Admin access only."); goto done; } } while (0)

    if (!strcmp(p, "/api/me")) {
        if (!logged) { send_json(fd, 200, "{\"success\":false}", NULL); goto done; }
        SB sb; sb_init(&sb); session_json(&sb, &me); send_sb(fd, 200, &sb); sb_free(&sb);

    } else if (!strcmp(p, "/api/register") || !strcmp(p, "/api/login")) {
        NEED_POST(); NEED_DB();
        SessionInfo info;
        int rc;
        param(rq, "email", b, sizeof b); param(rq, "password", c2, sizeof c2);
        if (!strcmp(p, "/api/register")) { param(rq, "name", a, sizeof a); rc = user_register(db, a, b, c2, &info, msg, sizeof msg); }
        else rc = user_login(db, b, c2, &info, msg, sizeof msg);
        if (rc) { send_msg(fd, 400, 0, msg); goto done; }
        char token[65], ck[160];
        session_create(&info, token);
        cookie_header(ck, sizeof ck, token);
        SB sb; sb_init(&sb); session_json(&sb, &info);
        respond(fd, 200, "application/json", sb.p, sb.len, ck);
        sb_free(&sb);

    } else if (!strcmp(p, "/api/logout")) {
        NEED_POST();
        session_destroy(rq->sid);
        send_json(fd, 200, "{\"success\":true}", "Set-Cookie: sid=; Path=/; Max-Age=0\r\n");

    } else if (!strcmp(p, "/api/categories")) {
        NEED_DB();
        SB sb; sb_init(&sb);
        if (categories_json(db, &sb) == 0) send_sb(fd, 200, &sb); else send_msg(fd, 500, 0, "Database error.");
        sb_free(&sb);

    } else if (!strcmp(p, "/api/products")) {
        NEED_DB();
        param(rq, "q", a, sizeof a); param(rq, "category", b, sizeof b); param(rq, "min", c2, sizeof c2);
        param(rq, "max", d, sizeof d); param(rq, "sort", e, sizeof e);
        SB sb; sb_init(&sb);
        if (products_json(db, a, atoi(b), c2, d, e, &sb) == 0) send_sb(fd, 200, &sb); else send_msg(fd, 500, 0, "Database error.");
        sb_free(&sb);

    } else if (!strcmp(p, "/api/checkout")) {
        NEED_POST(); NEED_LOGIN(); NEED_DB();
        param(rq, "items", a, sizeof a);
        param(rq, "payment_method", b, sizeof b);
        param(rq, "full_name", c2, sizeof c2);
        param(rq, "phone", d, sizeof d);
        param(rq, "address", e, sizeof e);
        param(rq, "city", f, sizeof f);
        param(rq, "state", g, sizeof g);
        char pin[32]; param(rq, "pincode", pin, sizeof pin);
        Item items[MAX_ITEMS];
        int n = items_parse(a, items, MAX_ITEMS);
        OrderResult r;
        memset(&r, 0, sizeof r);
        if (n < 0) r.status = ORDER_BAD_INPUT;
        else r = order_place_checkout(db, me.user_id, items, n, b, c2, d, e, f, g, pin);
        order_message(&r, msg, sizeof msg);
        sync_stats_record(r.status == ORDER_OK, r.status == ORDER_INSUFFICIENT || r.status == ORDER_NOT_FOUND || r.status == ORDER_BAD_INPUT,
                          r.status == ORDER_DB_ERROR);
        SB sb; sb_init(&sb);
        sb_catf(&sb, "{\"success\":%s,\"order_id\":%ld,\"message\":", r.status == ORDER_OK ? "true" : "false", r.order_id);
        sb_json(&sb, msg);
        sb_cat(&sb, "}");
        send_sb(fd, r.status == ORDER_DB_ERROR ? 500 : r.status == ORDER_BAD_INPUT ? 400 : 200, &sb);
        sb_free(&sb);

    } else if (!strcmp(p, "/api/orders")) {
        NEED_LOGIN(); NEED_DB();
        SB sb; sb_init(&sb);
        if (orders_json(db, me.user_id, &sb) == 0) send_sb(fd, 200, &sb); else send_msg(fd, 500, 0, "Database error.");
        sb_free(&sb);

    } else if (!strcmp(p, "/api/orders/cancel")) {
        NEED_POST(); NEED_LOGIN(); NEED_DB();
        param(rq, "order_id", a, sizeof a);
        int rc = order_cancel(db, me.user_id, atol(a), msg, sizeof msg);
        send_msg(fd, rc ? 400 : 200, rc == 0, msg);

    } else if (!strcmp(p, "/api/admin/category")) {
        NEED_POST(); NEED_ADMIN(); NEED_DB();
        param(rq, "name", a, sizeof a);
        int rc = admin_add_category(db, a, msg, sizeof msg);
        send_msg(fd, rc ? 400 : 200, rc == 0, msg);

    } else if (!strcmp(p, "/api/admin/product")) {
        NEED_POST(); NEED_ADMIN(); NEED_DB();
        param(rq, "name", a, sizeof a); param(rq, "sku", b, sizeof b); param(rq, "category_id", c2, sizeof c2);
        param(rq, "price", d, sizeof d); param(rq, "stock", e, sizeof e);
        param(rq, "image_url", f, sizeof f); param(rq, "description", g, sizeof g);
        int rc = admin_add_product(db, a, b, atoi(c2), d, atoi(e), f, g, msg, sizeof msg);
        send_msg(fd, rc ? 400 : 200, rc == 0, msg);

    } else if (!strcmp(p, "/api/admin/stock")) {
        NEED_POST(); NEED_ADMIN(); NEED_DB();
        param(rq, "product_id", a, sizeof a); param(rq, "stock", b, sizeof b);
        int rc = admin_set_stock(db, atoi(a), atoi(b), "ADMIN ADJUST", msg, sizeof msg);
        send_msg(fd, rc ? 400 : 200, rc == 0, msg);

    } else if (!strcmp(p, "/api/admin/orders")) {
        NEED_ADMIN(); NEED_DB();
        SB sb; sb_init(&sb);
        if (orders_json(db, 0, &sb) == 0) send_sb(fd, 200, &sb); else send_msg(fd, 500, 0, "Database error.");
        sb_free(&sb);

    } else if (!strcmp(p, "/api/admin/order_status")) {
        NEED_POST(); NEED_ADMIN(); NEED_DB();
        param(rq, "order_id", a, sizeof a); param(rq, "status", b, sizeof b);
        int rc = admin_order_status(db, atol(a), b, msg, sizeof msg);
        send_msg(fd, rc ? 400 : 200, rc == 0, msg);

    } else if (!strcmp(p, "/api/admin/demo_race")) {
        NEED_POST(); NEED_ADMIN(); NEED_DB();
        param(rq, "product_id", a, sizeof a); param(rq, "stock", b, sizeof b); param(rq, "quantity", c2, sizeof c2);
        SB sb; sb_init(&sb);
        int rc = race_run(db, atoi(a), b[0] ? atoi(b) : 5, c2[0] ? atoi(c2) : 4, &sb, msg, sizeof msg);
        if (rc == 0) send_sb(fd, 200, &sb); else send_msg(fd, 400, 0, msg);
        sb_free(&sb);

    } else if (!strcmp(p, "/api/admin/consistency")) {
        NEED_ADMIN(); NEED_DB();
        SB sb; sb_init(&sb);
        if (consistency_json(db, &sb) == 0) send_sb(fd, 200, &sb); else send_msg(fd, 500, 0, "Database error.");
        sb_free(&sb);

    } else if (!strcmp(p, "/api/stats")) {
        Stats s; sync_stats_get(&s);
        char o[200];
        snprintf(o, sizeof o, "{\"orders_ok\":%ld,\"orders_rejected\":%ld,\"orders_error\":%ld}",
                 s.orders_ok, s.orders_rejected, s.orders_error);
        send_json(fd, 200, o, NULL);

    } else {
        (void)is_get;
        send_msg(fd, 404, 0, "Unknown endpoint.");
    }
done:
    if (lz.db) { mysql_close(lz.db); }
#undef NEED_DB
#undef NEED_POST
#undef NEED_LOGIN
#undef NEED_ADMIN
}

/* ---------- connection worker (one pthread per connection) ---------- */

static void *worker(void *arg) {
    int fd = (int)(long)arg;
    char buf[REQ_MAX + 1];
    size_t total = 0;
    char *hdr_end = NULL;

    while (total < REQ_MAX) {
        ssize_t n = recv(fd, buf + total, REQ_MAX - total, 0);
        if (n <= 0) break;
        total += (size_t)n;
        buf[total] = '\0';
        hdr_end = strstr(buf, "\r\n\r\n");
        if (hdr_end) break;
    }
    if (!hdr_end) goto done;

    size_t clen = 0;
    const char *cl = strcasestr(buf, "\r\nContent-Length:");
    if (cl && cl < hdr_end) clen = (size_t)atol(cl + 17);
    size_t head = (size_t)(hdr_end + 4 - buf);
    if (clen > REQ_MAX - head) { send_msg(fd, 400, 0, "Request too large."); goto done; }
    while (total < head + clen) {
        ssize_t n = recv(fd, buf + total, head + clen - total, 0);
        if (n <= 0) break;
        total += (size_t)n;
    }
    buf[total] = '\0';

    Req rq;
    memset(&rq, 0, sizeof rq);
    char target[1024];
    if (sscanf(buf, "%7s %1023s", rq.method, target) != 2) { send_msg(fd, 400, 0, "Bad request."); goto done; }
    if (strlen(target) >= sizeof rq.path) { send_msg(fd, 400, 0, "URL too long."); goto done; }
    char *q = strchr(target, '?');
    if (q) *q++ = '\0';
    rq.query = q ? q : "";
    rq.body = buf + head;
    snprintf(rq.path, sizeof rq.path, "%s", target);
    parse_cookie(buf, rq.sid, sizeof rq.sid);

    if (!strcmp(rq.path, "/") || !strcmp(rq.path, "/index.html")) serve_static(fd, "index.html", "text/html; charset=utf-8");
    else if (!strcmp(rq.path, "/style.css"))  serve_static(fd, "style.css", "text/css; charset=utf-8");
    else if (!strcmp(rq.path, "/script.js"))  serve_static(fd, "script.js", "application/javascript; charset=utf-8");
    else if (!strncmp(rq.path, "/api/", 5))   handle_api(fd, &rq);
    else send_msg(fd, 404, 0, "Not found.");

done:
    close(fd);
    mysql_thread_end();
    sync_worker_release();
    return NULL;
}

int http_serve(int port, const char *web_root) {
    g_web_root = web_root;
    sync_init(MAX_WORKERS);

    int s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) { perror("socket"); return -1; }
    int one = 1;
    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof addr);
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons((uint16_t)port);
    if (bind(s, (struct sockaddr *)&addr, sizeof addr) < 0) { perror("bind"); return -1; }
    if (listen(s, 128) < 0) { perror("listen"); return -1; }
    printf("[server] listening on http://localhost:%d (frontend: %s)\n", port, web_root);

    for (;;) {
        int fd = accept(s, NULL, NULL);
        if (fd < 0) continue;
        sync_worker_acquire();                       /* bound concurrent threads */
        pthread_t t;
        pthread_attr_t at;
        pthread_attr_init(&at);
        pthread_attr_setdetachstate(&at, PTHREAD_CREATE_DETACHED);
        if (pthread_create(&t, &at, worker, (void *)(long)fd) != 0) { close(fd); sync_worker_release(); }
        pthread_attr_destroy(&at);
    }
}
