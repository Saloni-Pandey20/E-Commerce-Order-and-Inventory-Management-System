-- AARONI: promote the separately registered admin account.
-- 1) First register the admin account normally through the website.
-- 2) Replace the email below with the exact email used for that account.
-- 3) Run this file against the existing aaroni_c database.
-- This does not delete or modify customer orders.

USE aaroni_c;

UPDATE users
SET role = 'admin'
WHERE email = 'REPLACE_WITH_ADMIN_EMAIL';

-- Verify that exactly the intended account has the admin role:
SELECT id, name, email, role
FROM users
WHERE email = 'REPLACE_WITH_ADMIN_EMAIL';
