-- Run once as MySQL root: creates the application user used by the C backend.
CREATE USER IF NOT EXISTS 'ecom'@'localhost'  IDENTIFIED BY 'ecom_pass';
CREATE USER IF NOT EXISTS 'ecom'@'127.0.0.1'  IDENTIFIED BY 'ecom_pass';
GRANT SELECT, INSERT, UPDATE, DELETE ON aaroni_c.* TO 'ecom'@'localhost';
GRANT SELECT, INSERT, UPDATE, DELETE ON aaroni_c.* TO 'ecom'@'127.0.0.1';
FLUSH PRIVILEGES;
