-- AARONI (C edition): database schema. Needs MySQL 8.0.16+ or MariaDB 10.2+ (CHECK constraints enforced).
DROP DATABASE IF EXISTS aaroni_c;
CREATE DATABASE aaroni_c CHARACTER SET utf8mb4;
USE aaroni_c;

-- InnoDB gives transactions, row-level locks and foreign keys.
CREATE TABLE users (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(100) NOT NULL,
    email         VARCHAR(190) NOT NULL UNIQUE,
    password_hash VARCHAR(160) NOT NULL,              -- crypt() SHA-512; '!' = cannot log in
    role          ENUM('customer','admin') NOT NULL DEFAULT 'customer',
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE categories (
    id    INT AUTO_INCREMENT PRIMARY KEY,
    name  VARCHAR(80)  NOT NULL UNIQUE,
    slug  VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE products (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    category_id  INT NULL,
    name         VARCHAR(160)  NOT NULL,
    description  TEXT,
    price        DECIMAL(10,2) NOT NULL,
    image_url    VARCHAR(500),
    stock        INT NOT NULL,
    sku          VARCHAR(50) UNIQUE,
    active       TINYINT(1) NOT NULL DEFAULT 1,
    created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_price_nonneg CHECK (price >= 0),
    CONSTRAINT chk_stock_nonneg CHECK (stock >= 0),     -- last line of defence against overselling
    CONSTRAINT fk_prod_cat FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
    INDEX idx_prod_cat_price (category_id, price),
    INDEX idx_prod_price (price),
    INDEX idx_prod_name (name)
) ENGINE=InnoDB;

CREATE TABLE orders (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    total       DECIMAL(12,2) NOT NULL,
    status      ENUM('PLACED','PROCESSING','SHIPPED','DELIVERED','CANCELLED') NOT NULL DEFAULT 'PLACED',
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_order_user FOREIGN KEY (user_id) REFERENCES users(id),
    INDEX idx_orders_user (user_id, created_at),
    INDEX idx_orders_status (status)
) ENGINE=InnoDB;

CREATE TABLE order_items (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    order_id      INT NOT NULL,
    product_id    INT NOT NULL,
    product_name  VARCHAR(160) NOT NULL,            -- snapshot, so history survives renames
    unit_price    DECIMAL(10,2) NOT NULL,           -- snapshot
    quantity      INT NOT NULL,
    CONSTRAINT chk_qty_positive CHECK (quantity > 0),
    CONSTRAINT fk_item_order   FOREIGN KEY (order_id)   REFERENCES orders(id) ON DELETE CASCADE,
    CONSTRAINT fk_item_product FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB;

-- Audit trail of every stock change. stock must always equal SUM(change_qty):
-- this is what the consistency check verifies.
CREATE TABLE inventory_movements (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    product_id  INT NOT NULL,
    change_qty  INT NOT NULL,
    reason      VARCHAR(60) NOT NULL,
    order_id    INT NULL,
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_mov_product FOREIGN KEY (product_id) REFERENCES products(id),
    CONSTRAINT fk_mov_order   FOREIGN KEY (order_id)   REFERENCES orders(id),
    INDEX idx_mov_product (product_id, created_at)
) ENGINE=InnoDB;
