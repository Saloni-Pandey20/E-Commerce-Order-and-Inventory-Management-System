-- Sample data. No default administrator account is created.
-- demo_a / demo_b are the two customers used by the built-in concurrency demo; they cannot log in.
USE aaroni_c;

INSERT INTO users(name,email,password_hash,role) VALUES
('Customer A','demo_a@shop.local','!','customer'),
('Customer B','demo_b@shop.local','!','customer');

INSERT INTO categories(name,slug) VALUES
('Men''s Wear','mens-wear'),
('Women''s Wear','womens-wear'),
('Footwear','footwear'),
('Bags & Wallets','bags-wallets'),
('Watches','watches'),
('Jewellery','jewellery');

-- Men's Wear
INSERT INTO products(category_id,name,description,price,image_url,stock,sku) VALUES
((SELECT id FROM categories WHERE slug='mens-wear'),'Classic White Shirt','Classic White Shirt from the AARONI Men''s Wear collection. Comfortable, stylish and made for everyday wear.',899,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Classic+White+Shirt',25,'AAR-MEN-001'),
((SELECT id FROM categories WHERE slug='mens-wear'),'Slim Fit Chinos','Slim Fit Chinos from the AARONI Men''s Wear collection. Comfortable, stylish and made for everyday wear.',1299,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Slim+Fit+Chinos',18,'AAR-MEN-002'),
((SELECT id FROM categories WHERE slug='mens-wear'),'Denim Jacket','Denim Jacket from the AARONI Men''s Wear collection. Comfortable, stylish and made for everyday wear.',2199,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Denim+Jacket',12,'AAR-MEN-003'),
((SELECT id FROM categories WHERE slug='mens-wear'),'Polo T-Shirt','Polo T-Shirt from the AARONI Men''s Wear collection. Comfortable, stylish and made for everyday wear.',599,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Polo+T-Shirt',30,'AAR-MEN-004'),
((SELECT id FROM categories WHERE slug='mens-wear'),'Graphic Tee','Graphic Tee from the AARONI Men''s Wear collection. Comfortable, stylish and made for everyday wear.',499,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Graphic+Tee',40,'AAR-MEN-005'),
((SELECT id FROM categories WHERE slug='mens-wear'),'Formal Blazer','Formal Blazer from the AARONI Men''s Wear collection. Comfortable, stylish and made for everyday wear.',3499,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Formal+Blazer',8,'AAR-MEN-006'),
((SELECT id FROM categories WHERE slug='mens-wear'),'Cargo Joggers','Cargo Joggers from the AARONI Men''s Wear collection. Comfortable, stylish and made for everyday wear.',999,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Cargo+Joggers',22,'AAR-MEN-007'),
((SELECT id FROM categories WHERE slug='mens-wear'),'Linen Casual Shirt','Linen Casual Shirt from the AARONI Men''s Wear collection. Comfortable, stylish and made for everyday wear.',1099,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Linen+Casual+Shirt',15,'AAR-MEN-008'),
((SELECT id FROM categories WHERE slug='mens-wear'),'Hooded Sweatshirt','Hooded Sweatshirt from the AARONI Men''s Wear collection. Comfortable, stylish and made for everyday wear.',1399,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Hooded+Sweatshirt',20,'AAR-MEN-009'),
((SELECT id FROM categories WHERE slug='mens-wear'),'Straight Fit Jeans','Straight Fit Jeans from the AARONI Men''s Wear collection. Comfortable, stylish and made for everyday wear.',1499,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Straight+Fit+Jeans',10,'AAR-MEN-010');

-- Women's Wear
INSERT INTO products(category_id,name,description,price,image_url,stock,sku) VALUES
((SELECT id FROM categories WHERE slug='womens-wear'),'Floral Summer Dress','Floral Summer Dress from the AARONI Women''s Wear collection. Comfortable, stylish and made for everyday wear.',1299,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Floral+Summer+Dress',25,'AAR-WOM-001'),
((SELECT id FROM categories WHERE slug='womens-wear'),'Cotton Kurti','Cotton Kurti from the AARONI Women''s Wear collection. Comfortable, stylish and made for everyday wear.',799,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Cotton+Kurti',18,'AAR-WOM-002'),
((SELECT id FROM categories WHERE slug='womens-wear'),'High Waist Jeans','High Waist Jeans from the AARONI Women''s Wear collection. Comfortable, stylish and made for everyday wear.',1599,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=High+Waist+Jeans',12,'AAR-WOM-003'),
((SELECT id FROM categories WHERE slug='womens-wear'),'Satin Blouse','Satin Blouse from the AARONI Women''s Wear collection. Comfortable, stylish and made for everyday wear.',999,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Satin+Blouse',30,'AAR-WOM-004'),
((SELECT id FROM categories WHERE slug='womens-wear'),'Pleated Midi Skirt','Pleated Midi Skirt from the AARONI Women''s Wear collection. Comfortable, stylish and made for everyday wear.',1099,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Pleated+Midi+Skirt',40,'AAR-WOM-005'),
((SELECT id FROM categories WHERE slug='womens-wear'),'Anarkali Suit','Anarkali Suit from the AARONI Women''s Wear collection. Comfortable, stylish and made for everyday wear.',2499,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Anarkali+Suit',8,'AAR-WOM-006'),
((SELECT id FROM categories WHERE slug='womens-wear'),'Knit Cardigan','Knit Cardigan from the AARONI Women''s Wear collection. Comfortable, stylish and made for everyday wear.',1399,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Knit+Cardigan',22,'AAR-WOM-007'),
((SELECT id FROM categories WHERE slug='womens-wear'),'Palazzo Pants','Palazzo Pants from the AARONI Women''s Wear collection. Comfortable, stylish and made for everyday wear.',699,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Palazzo+Pants',15,'AAR-WOM-008'),
((SELECT id FROM categories WHERE slug='womens-wear'),'Denim Skirt','Denim Skirt from the AARONI Women''s Wear collection. Comfortable, stylish and made for everyday wear.',899,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Denim+Skirt',20,'AAR-WOM-009'),
((SELECT id FROM categories WHERE slug='womens-wear'),'Printed Saree','Printed Saree from the AARONI Women''s Wear collection. Comfortable, stylish and made for everyday wear.',1999,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Printed+Saree',10,'AAR-WOM-010');

-- Footwear
INSERT INTO products(category_id,name,description,price,image_url,stock,sku) VALUES
((SELECT id FROM categories WHERE slug='footwear'),'White Sneakers','White Sneakers from the AARONI Footwear collection. Comfortable, stylish and made for everyday wear.',1999,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=White+Sneakers',25,'AAR-FTW-001'),
((SELECT id FROM categories WHERE slug='footwear'),'Running Shoes','Running Shoes from the AARONI Footwear collection. Comfortable, stylish and made for everyday wear.',2499,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Running+Shoes',18,'AAR-FTW-002'),
((SELECT id FROM categories WHERE slug='footwear'),'Leather Loafers','Leather Loafers from the AARONI Footwear collection. Comfortable, stylish and made for everyday wear.',2799,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Leather+Loafers',12,'AAR-FTW-003'),
((SELECT id FROM categories WHERE slug='footwear'),'Strappy Sandals','Strappy Sandals from the AARONI Footwear collection. Comfortable, stylish and made for everyday wear.',899,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Strappy+Sandals',30,'AAR-FTW-004'),
((SELECT id FROM categories WHERE slug='footwear'),'Casual Flip Flops','Casual Flip Flops from the AARONI Footwear collection. Comfortable, stylish and made for everyday wear.',399,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Casual+Flip+Flops',40,'AAR-FTW-005'),
((SELECT id FROM categories WHERE slug='footwear'),'Ankle Boots','Ankle Boots from the AARONI Footwear collection. Comfortable, stylish and made for everyday wear.',3199,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Ankle+Boots',8,'AAR-FTW-006'),
((SELECT id FROM categories WHERE slug='footwear'),'Canvas Shoes','Canvas Shoes from the AARONI Footwear collection. Comfortable, stylish and made for everyday wear.',1199,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Canvas+Shoes',22,'AAR-FTW-007'),
((SELECT id FROM categories WHERE slug='footwear'),'Formal Oxford Shoes','Formal Oxford Shoes from the AARONI Footwear collection. Comfortable, stylish and made for everyday wear.',3299,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Formal+Oxford+Shoes',15,'AAR-FTW-008'),
((SELECT id FROM categories WHERE slug='footwear'),'Ballet Flats','Ballet Flats from the AARONI Footwear collection. Comfortable, stylish and made for everyday wear.',999,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Ballet+Flats',20,'AAR-FTW-009'),
((SELECT id FROM categories WHERE slug='footwear'),'Sports Slides','Sports Slides from the AARONI Footwear collection. Comfortable, stylish and made for everyday wear.',599,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Sports+Slides',10,'AAR-FTW-010');

-- Bags & Wallets
INSERT INTO products(category_id,name,description,price,image_url,stock,sku) VALUES
((SELECT id FROM categories WHERE slug='bags-wallets'),'Leather Backpack','Leather Backpack from the AARONI Bags & Wallets collection. Comfortable, stylish and made for everyday wear.',2499,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Leather+Backpack',25,'AAR-BAG-001'),
((SELECT id FROM categories WHERE slug='bags-wallets'),'Crossbody Sling Bag','Crossbody Sling Bag from the AARONI Bags & Wallets collection. Comfortable, stylish and made for everyday wear.',1299,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Crossbody+Sling+Bag',18,'AAR-BAG-002'),
((SELECT id FROM categories WHERE slug='bags-wallets'),'Laptop Messenger Bag','Laptop Messenger Bag from the AARONI Bags & Wallets collection. Comfortable, stylish and made for everyday wear.',2199,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Laptop+Messenger+Bag',12,'AAR-BAG-003'),
((SELECT id FROM categories WHERE slug='bags-wallets'),'Canvas Tote','Canvas Tote from the AARONI Bags & Wallets collection. Comfortable, stylish and made for everyday wear.',699,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Canvas+Tote',30,'AAR-BAG-004'),
((SELECT id FROM categories WHERE slug='bags-wallets'),'Mini Clutch','Mini Clutch from the AARONI Bags & Wallets collection. Comfortable, stylish and made for everyday wear.',899,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Mini+Clutch',40,'AAR-BAG-005'),
((SELECT id FROM categories WHERE slug='bags-wallets'),'Travel Duffle Bag','Travel Duffle Bag from the AARONI Bags & Wallets collection. Comfortable, stylish and made for everyday wear.',2799,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Travel+Duffle+Bag',8,'AAR-BAG-006'),
((SELECT id FROM categories WHERE slug='bags-wallets'),'Bifold Leather Wallet','Bifold Leather Wallet from the AARONI Bags & Wallets collection. Comfortable, stylish and made for everyday wear.',799,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Bifold+Leather+Wallet',22,'AAR-BAG-007'),
((SELECT id FROM categories WHERE slug='bags-wallets'),'Card Holder','Card Holder from the AARONI Bags & Wallets collection. Comfortable, stylish and made for everyday wear.',399,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Card+Holder',15,'AAR-BAG-008'),
((SELECT id FROM categories WHERE slug='bags-wallets'),'Ladies Handbag','Ladies Handbag from the AARONI Bags & Wallets collection. Comfortable, stylish and made for everyday wear.',1799,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Ladies+Handbag',20,'AAR-BAG-009'),
((SELECT id FROM categories WHERE slug='bags-wallets'),'School Backpack','School Backpack from the AARONI Bags & Wallets collection. Comfortable, stylish and made for everyday wear.',1099,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=School+Backpack',10,'AAR-BAG-010');

-- Watches
INSERT INTO products(category_id,name,description,price,image_url,stock,sku) VALUES
((SELECT id FROM categories WHERE slug='watches'),'Minimal Analog Watch','Minimal Analog Watch from the AARONI Watches collection. Comfortable, stylish and made for everyday wear.',1999,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Minimal+Analog+Watch',25,'AAR-WAT-001'),
((SELECT id FROM categories WHERE slug='watches'),'Chronograph Steel Watch','Chronograph Steel Watch from the AARONI Watches collection. Comfortable, stylish and made for everyday wear.',3999,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Chronograph+Steel+Watch',18,'AAR-WAT-002'),
((SELECT id FROM categories WHERE slug='watches'),'Digital Sports Watch','Digital Sports Watch from the AARONI Watches collection. Comfortable, stylish and made for everyday wear.',1499,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Digital+Sports+Watch',12,'AAR-WAT-003'),
((SELECT id FROM categories WHERE slug='watches'),'Leather Strap Watch','Leather Strap Watch from the AARONI Watches collection. Comfortable, stylish and made for everyday wear.',2499,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Leather+Strap+Watch',30,'AAR-WAT-004'),
((SELECT id FROM categories WHERE slug='watches'),'Ladies Rose Gold Watch','Ladies Rose Gold Watch from the AARONI Watches collection. Comfortable, stylish and made for everyday wear.',2799,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Ladies+Rose+Gold+Watch',40,'AAR-WAT-005'),
((SELECT id FROM categories WHERE slug='watches'),'Smart Fitness Band','Smart Fitness Band from the AARONI Watches collection. Comfortable, stylish and made for everyday wear.',1999,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Smart+Fitness+Band',8,'AAR-WAT-006'),
((SELECT id FROM categories WHERE slug='watches'),'Classic Black Dial Watch','Classic Black Dial Watch from the AARONI Watches collection. Comfortable, stylish and made for everyday wear.',2199,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Classic+Black+Dial+Watch',22,'AAR-WAT-007'),
((SELECT id FROM categories WHERE slug='watches'),'Mesh Strap Watch','Mesh Strap Watch from the AARONI Watches collection. Comfortable, stylish and made for everyday wear.',2999,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Mesh+Strap+Watch',15,'AAR-WAT-008'),
((SELECT id FROM categories WHERE slug='watches'),'Vintage Style Watch','Vintage Style Watch from the AARONI Watches collection. Comfortable, stylish and made for everyday wear.',1799,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Vintage+Style+Watch',20,'AAR-WAT-009'),
((SELECT id FROM categories WHERE slug='watches'),'Kids Digital Watch','Kids Digital Watch from the AARONI Watches collection. Comfortable, stylish and made for everyday wear.',699,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Kids+Digital+Watch',10,'AAR-WAT-010');

-- Jewellery
INSERT INTO products(category_id,name,description,price,image_url,stock,sku) VALUES
((SELECT id FROM categories WHERE slug='jewellery'),'Pearl Drop Earrings','Pearl Drop Earrings from the AARONI Jewellery collection. Comfortable, stylish and made for everyday wear.',599,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Pearl+Drop+Earrings',25,'AAR-JWL-001'),
((SELECT id FROM categories WHERE slug='jewellery'),'Gold Tone Chain Necklace','Gold Tone Chain Necklace from the AARONI Jewellery collection. Comfortable, stylish and made for everyday wear.',899,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Gold+Tone+Chain+Necklace',18,'AAR-JWL-002'),
((SELECT id FROM categories WHERE slug='jewellery'),'Silver Hoop Earrings','Silver Hoop Earrings from the AARONI Jewellery collection. Comfortable, stylish and made for everyday wear.',499,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Silver+Hoop+Earrings',12,'AAR-JWL-003'),
((SELECT id FROM categories WHERE slug='jewellery'),'Charm Bracelet','Charm Bracelet from the AARONI Jewellery collection. Comfortable, stylish and made for everyday wear.',699,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Charm+Bracelet',30,'AAR-JWL-004'),
((SELECT id FROM categories WHERE slug='jewellery'),'Statement Ring','Statement Ring from the AARONI Jewellery collection. Comfortable, stylish and made for everyday wear.',399,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Statement+Ring',40,'AAR-JWL-005'),
((SELECT id FROM categories WHERE slug='jewellery'),'Oxidised Jhumkas','Oxidised Jhumkas from the AARONI Jewellery collection. Comfortable, stylish and made for everyday wear.',549,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Oxidised+Jhumkas',8,'AAR-JWL-006'),
((SELECT id FROM categories WHERE slug='jewellery'),'Layered Pendant Set','Layered Pendant Set from the AARONI Jewellery collection. Comfortable, stylish and made for everyday wear.',1099,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Layered+Pendant+Set',22,'AAR-JWL-007'),
((SELECT id FROM categories WHERE slug='jewellery'),'Beaded Anklet','Beaded Anklet from the AARONI Jewellery collection. Comfortable, stylish and made for everyday wear.',299,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Beaded+Anklet',15,'AAR-JWL-008'),
((SELECT id FROM categories WHERE slug='jewellery'),'Stud Earring Set','Stud Earring Set from the AARONI Jewellery collection. Comfortable, stylish and made for everyday wear.',449,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Stud+Earring+Set',20,'AAR-JWL-009'),
((SELECT id FROM categories WHERE slug='jewellery'),'Bangle Set','Bangle Set from the AARONI Jewellery collection. Comfortable, stylish and made for everyday wear.',799,'https://placehold.co/600x600/e8e0d6/2b2b2b?text=Bangle+Set',10,'AAR-JWL-010');

-- Opening stock goes into the audit trail so stock = SUM(movements) from day one.
INSERT INTO inventory_movements(product_id,change_qty,reason) SELECT id,stock,'INITIAL' FROM products;
