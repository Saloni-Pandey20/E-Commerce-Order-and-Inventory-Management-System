-- AARONI additive migration. Safe for the existing aaroni_c database.
-- Run once: sudo mysql < database/upgrade_existing_database.sql
USE aaroni_c;

SET @s = (SELECT IF(COUNT(*)=0,
 'ALTER TABLE orders ADD COLUMN payment_method ENUM(''COD'',''UPI'',''CARD'',''WALLET'',''NETBANKING'') NOT NULL DEFAULT ''COD''',
 'SELECT "payment_method already exists"') FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND COLUMN_NAME='payment_method');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = (SELECT IF(COUNT(*)=0,
 'ALTER TABLE orders ADD COLUMN payment_status ENUM(''PENDING'',''PAID'',''REFUNDED'',''CANCELLED'') NOT NULL DEFAULT ''PENDING''',
 'SELECT "payment_status already exists"') FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND COLUMN_NAME='payment_status');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = (SELECT IF(COUNT(*)=0,
 'ALTER TABLE orders ADD COLUMN payment_ref VARCHAR(64) NULL',
 'SELECT "payment_ref already exists"') FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND COLUMN_NAME='payment_ref');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = (SELECT IF(COUNT(*)=0,
 'ALTER TABLE orders ADD COLUMN payment_detail VARCHAR(120) NULL',
 'SELECT "payment_detail already exists"') FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND COLUMN_NAME='payment_detail');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @s = (SELECT IF(COUNT(*)=0,
 'ALTER TABLE orders ADD COLUMN shipping_name VARCHAR(100) NULL',
 'SELECT "shipping_name already exists"') FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND COLUMN_NAME='shipping_name');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = (SELECT IF(COUNT(*)=0,
 'ALTER TABLE orders ADD COLUMN shipping_phone VARCHAR(20) NULL',
 'SELECT "shipping_phone already exists"') FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND COLUMN_NAME='shipping_phone');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = (SELECT IF(COUNT(*)=0,
 'ALTER TABLE orders ADD COLUMN shipping_address VARCHAR(250) NULL',
 'SELECT "shipping_address already exists"') FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND COLUMN_NAME='shipping_address');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = (SELECT IF(COUNT(*)=0,
 'ALTER TABLE orders ADD COLUMN shipping_city VARCHAR(80) NULL',
 'SELECT "shipping_city already exists"') FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND COLUMN_NAME='shipping_city');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = (SELECT IF(COUNT(*)=0,
 'ALTER TABLE orders ADD COLUMN shipping_state VARCHAR(80) NULL',
 'SELECT "shipping_state already exists"') FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND COLUMN_NAME='shipping_state');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = (SELECT IF(COUNT(*)=0,
 'ALTER TABLE orders ADD COLUMN shipping_pincode CHAR(6) NULL',
 'SELECT "shipping_pincode already exists"') FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND COLUMN_NAME='shipping_pincode');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = (SELECT IF(COUNT(*)=0,
 'ALTER TABLE orders ADD COLUMN estimated_delivery DATE NULL',
 'SELECT "estimated_delivery already exists"') FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND COLUMN_NAME='estimated_delivery');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;

CREATE TABLE IF NOT EXISTS customer_addresses (
  id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL,
  label VARCHAR(30) NOT NULL DEFAULT 'Home', full_name VARCHAR(100) NOT NULL,
  phone VARCHAR(20) NOT NULL, address_line VARCHAR(250) NOT NULL,
  city VARCHAR(80) NOT NULL, state VARCHAR(80) NOT NULL, pincode CHAR(6) NOT NULL,
  is_default TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_address_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_address_user (user_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS product_images (
  id INT AUTO_INCREMENT PRIMARY KEY, product_id INT NOT NULL,
  image_url VARCHAR(500) NOT NULL, sort_order INT NOT NULL DEFAULT 0,
  CONSTRAINT fk_product_images_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  INDEX idx_product_images_order (product_id, sort_order)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS product_reviews (
  id INT AUTO_INCREMENT PRIMARY KEY, product_id INT NOT NULL, user_id INT NOT NULL,
  rating TINYINT NOT NULL, review_text TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_review_rating CHECK (rating BETWEEN 1 AND 5),
  CONSTRAINT fk_review_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  CONSTRAINT fk_review_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY uq_review_user_product (user_id, product_id)
) ENGINE=InnoDB;
