// AARONI frontend: plain JavaScript talking to the C backend (same origin, /api/...).
// All text from the server is inserted with textContent (never innerHTML).

const state = { user: null, products: [], categories: [], cart: loadCart(), view: "shop", pendingProduct: null, pinVerified: false };
const $ = (id) => document.getElementById(id);

function loadCart() {
  try { return JSON.parse(localStorage.getItem("aaroni_cart") || "[]"); } catch (e) { return []; }
}
function saveCart() {
  try { localStorage.setItem("aaroni_cart", JSON.stringify(state.cart)); } catch (e) { /* storage may be blocked */ }
  $("bagCount").textContent = state.cart.reduce((n, i) => n + i.qty, 0);
}

function h(tag, attrs = {}, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") e.className = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v);
  }
  for (const k of kids.flat()) e.append(k instanceof Node ? k : document.createTextNode(String(k)));
  return e;
}
const money = (n) => "Rs. " + Number(n).toFixed(2);

async function api(path, method = "GET", data = null) {
  const opt = { method, credentials: "same-origin" };
  if (data) {
    opt.headers = { "Content-Type": "application/x-www-form-urlencoded" };
    opt.body = new URLSearchParams(data).toString();
  } else if (method === "POST") {
    opt.body = "";
  }
  try {
    const res = await fetch(path, opt);
    const j = await res.json().catch(() => ({}));
    j._status = res.status;
    return j;
  } catch (e) {
    return { success: false, message: "Could not reach the server.", _status: 0 };
  }
}

function say(text, ok) {
  const m = $("message");
  m.textContent = text;
  m.className = "message " + (ok ? "ok" : "fail");
  m.hidden = false;
  clearTimeout(say.t);
  say.t = setTimeout(() => { m.hidden = true; }, 9000);
}

// ---------- navigation ----------
function show(view) {
  state.view = view;
  document.querySelectorAll(".view").forEach((v) => { v.hidden = v.id !== "view-" + view; });
  document.querySelectorAll("nav a[data-view]").forEach((a) => a.classList.toggle("active", a.dataset.view === view));
  if (view === "shop") loadProducts();
  if (view === "bag") renderBag();
  if (view === "orders") loadOrders();
  if (view === "admin") loadAdmin();
}
document.addEventListener("click", (e) => {
  const a = e.target.closest("[data-view]");
  if (a) { e.preventDefault(); if (needsLogin(a.dataset.view)) return; show(a.dataset.view); }
});
function needsLogin(view) {
  if (["bag", "orders", "admin"].includes(view) && !state.user) {
    state.pendingView = view;
    say("Please log in or create an account to continue.", false);
    show("login");
    return true;
  }
  return false;
}

function renderUser() {
  const u = state.user;
  document.querySelectorAll(".auth-only").forEach((e) => { e.hidden = !u; });
  document.querySelectorAll(".admin-only").forEach((e) => { e.hidden = !(u && u.role === "admin"); });
  $("loginLink").hidden = !!u;
  $("logoutLink").hidden = !u;
  $("logoutLink").textContent = u ? "Logout (" + u.name.split(" ")[0] + ")" : "Logout";
}

async function loadMe() {
  const r = await api("/api/me");
  state.user = r.success ? r.user : null;
  renderUser();
}

// ---------- shop ----------
async function loadCategories() {
  const r = await api("/api/categories");
  state.categories = r.categories || [];
  const sel = $("fCategory");
  const cur = sel.value;
  sel.replaceChildren(h("option", { value: "0" }, "All categories"),
    ...state.categories.map((c) => h("option", { value: c.id }, c.name)));
  sel.value = cur || "0";
}

async function loadProducts() {
  const q = new URLSearchParams({
    q: $("searchBox").value.trim(), category: $("fCategory").value,
    min: $("fMin").value, max: $("fMax").value, sort: $("fSort").value,
  });
  const r = await api("/api/products?" + q);
  if (!r.products) { say(r.message || "Could not load products.", false); return; }
  state.products = r.products;
  $("resultCount").textContent = r.products.length + " product" + (r.products.length === 1 ? "" : "s");
  const grid = $("products");
  grid.replaceChildren();
  if (!r.products.length) grid.append(h("p", { class: "muted" }, "No products match. Try different filters."));
  for (const p of r.products) grid.append(productCard(p));
}

function productCard(p) {
  const cls = p.stock === 0 ? "out" : p.stock <= 5 ? "low" : "";
  const label = p.stock === 0 ? "Sold out" : "In stock: " + p.stock;
  const qty = h("input", { type: "number", min: "1", max: String(Math.max(1, p.stock)), value: "1" });
  const btn = h("button", { class: "btn", onclick: () => addToCart(p, parseInt(qty.value, 10) || 1) }, "Add to bag");
  if (p.stock === 0) { btn.disabled = true; qty.disabled = true; }
  const img = h("img", { src: p.image_url || "", alt: p.name, loading: "lazy" });
  img.addEventListener("error", () => { img.style.visibility = "hidden"; });
  return h("article", { class: "card" }, img,
    h("div", { class: "info" },
      h("small", {}, p.category || "AARONI"), h("h3", {}, p.name),
      h("span", { class: "price" }, money(p.price)), h("span", { class: "stock " + cls }, label),
      h("div", { class: "buy" }, qty, btn)));
}

function addToCart(p, qty) {
  if (!state.user) {
    state.pendingProduct = { product: p, qty };
    say("Please log in or sign up before adding products to your bag.", false);
    show("login");
    return;
  }
  if (qty < 1) return;
  const line = state.cart.find((i) => i.id === p.id);
  const have = line ? line.qty : 0;
  if (have + qty > p.stock) { say("Only " + p.stock + " in stock for " + p.name + ".", false); return; }
  if (line) { line.qty += qty; line.price = p.price; line.stock = p.stock; }
  else state.cart.push({ id: p.id, name: p.name, price: p.price, stock: p.stock, qty });
  saveCart();
  say(p.name + " added to your bag.", true);
}

// ---------- bag & checkout ----------
function renderBag() {
  const list = $("bagList");
  list.replaceChildren();
  let total = 0;
  if (!state.cart.length) list.append(h("p", { class: "muted" }, "Your bag is empty."));
  for (const it of state.cart) {
    total += it.price * it.qty;
    const qty = h("input", { type: "number", min: "1", value: String(it.qty) });
    qty.addEventListener("change", () => {
      it.qty = Math.max(1, parseInt(qty.value, 10) || 1); saveCart(); renderBag();
    });
    list.append(h("div", { class: "line" },
      h("div", { class: "grow" }, h("b", {}, it.name), h("div", { class: "muted" }, money(it.price) + " each")),
      qty, h("b", {}, money(it.price * it.qty)),
      h("button", { class: "btn small ghost", onclick: () => { state.cart = state.cart.filter((x) => x !== it); saveCart(); renderBag(); } }, "Remove")));
  }
  $("bagTotal").textContent = money(total);
  $("checkoutBtn").disabled = !state.cart.length;
  $("checkoutForm").hidden = true;
}

$("checkoutBtn").addEventListener("click", () => {
  if (!state.user) { say("Please log in to access your bag.", false); show("login"); return; }
  if (!state.cart.length) return;
  $("checkoutForm").hidden = false;
  $("checkoutForm").scrollIntoView({ behavior: "smooth", block: "start" });
});

async function verifyIndianPin(pin) {
  const out = $("pinResult");
  state.pinVerified = false;
  if (!/^[1-9][0-9]{5}$/.test(pin)) {
    out.textContent = "Enter a valid six-digit Indian PIN code.";
    return false;
  }
  out.textContent = "Checking postal directory…";
  try {
    const response = await fetch("https://api.postalpincode.in/pincode/" + encodeURIComponent(pin));
    const data = await response.json();
    const offices = data && data[0] && data[0].PostOffice;
    if (!offices || !offices.length) {
      out.textContent = "This PIN code was not found in the postal directory.";
      return false;
    }
    const deliveryOffice = offices.find(x => (x.DeliveryStatus || "").toLowerCase() === "delivery");
    if (!deliveryOffice) {
      out.textContent = "PIN code exists, but no delivery post office was returned. Please use another address.";
      return false;
    }
    $("checkoutForm").elements.city.value = deliveryOffice.District || $("checkoutForm").elements.city.value;
    $("checkoutForm").elements.state.value = deliveryOffice.State || $("checkoutForm").elements.state.value;
    out.textContent = "PIN code verified: " + deliveryOffice.District + ", " + deliveryOffice.State + ". Delivery-office listing found; final courier serviceability must still be confirmed.";
    state.pinVerified = true;
    return true;
  } catch (err) {
    out.textContent = "Could not reach the postal directory. Check your internet connection and try again.";
    return false;
  }
}

$("checkoutPin").addEventListener("blur", () => {
  if ($("checkoutPin").value.length === 6) verifyIndianPin($("checkoutPin").value);
});
$("checkoutPin").addEventListener("input", () => { state.pinVerified = false; $("pinResult").textContent = ""; });

$("checkoutForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!state.user) { say("Please log in first.", false); show("login"); return; }
  const form = formData(e.target);
  if (!state.cart.length) { say("Your bag is empty.", false); return; }
  if (!(await verifyIndianPin(form.pincode))) { say("Please enter a PIN code with a listed delivery post office.", false); return; }
  const btn = e.target.querySelector('button[type="submit"]');
  btn.disabled = true;
  const items = state.cart.map((i) => i.id + ":" + i.qty).join(",");
  const r = await api("/api/checkout", "POST", { ...form, items });
  say(r.message || "Checkout failed.", !!r.success);
  if (r.success) {
    state.cart = []; saveCart(); e.target.reset(); e.target.hidden = true;
    await loadOrders(); show("orders");
  }
  btn.disabled = false;
});

// ---------- orders ----------
function orderBlock(o, admin) {
  const items = h("ul", {}, o.items.map((i) => h("li", {}, i.qty + " x " + i.name + " (" + money(i.price) + ")")));
  const head = h("header", {},
    h("div", {}, h("b", {}, "Order #" + o.id), " ", h("span", { class: "muted" }, o.created + (admin ? " | " + o.customer : ""))),
    h("div", {}, h("b", {}, money(o.total)), " ", h("span", { class: "status " + o.status }, o.status)));
  // Create the order container before appending payment/delivery details.
  const box = h("div", { class: "order" }, head, items);
  box.append(h("p", { class: "muted" }, "Payment: " + (o.payment_method || "COD") + " (" + (o.payment_status || "PENDING") + ")"));
  if (o.estimated_delivery) box.append(h("p", { class: "muted" }, "Estimated delivery: " + o.estimated_delivery));
  if (o.shipping_pincode) box.append(h("p", { class: "muted" }, "Deliver to: " + o.shipping_address + ", " + o.shipping_city + ", " + o.shipping_state + " – " + o.shipping_pincode));
  if (!admin && (o.status === "PLACED" || o.status === "PROCESSING")) {
    box.append(h("button", { class: "btn small danger", onclick: async () => {
      const r = await api("/api/orders/cancel", "POST", { order_id: o.id });
      say(r.message, !!r.success); loadOrders();
    } }, "Cancel order"));
  }
  if (admin && o.status !== "CANCELLED") {
    const sel = h("select", {}, ["PROCESSING", "SHIPPED", "DELIVERED"].map((s) => h("option", { value: s }, s)));
    box.append(h("div", { class: "row" }, sel, h("button", { class: "btn small", onclick: async () => {
      const r = await api("/api/admin/order_status", "POST", { order_id: o.id, status: sel.value });
      say(r.message, !!r.success); loadAdmin();
    } }, "Update status")));
  }
  return box;
}

async function loadOrders() {
  const r = await api("/api/orders");
  const list = $("orderList");
  list.replaceChildren();
  if (!r.orders) { say(r.message || "Could not load orders.", false); return; }
  if (!r.orders.length) list.append(h("p", { class: "muted" }, "No orders yet."));
  for (const o of r.orders) list.append(orderBlock(o, false));
}

// ---------- admin ----------
async function loadAdmin() {
  const [prods, cats, ords] = await Promise.all([api("/api/products"), api("/api/categories"), api("/api/admin/orders")]);
  const products = prods.products || [];
  state.categories = cats.categories || [];

  $("demoProduct").replaceChildren(...products.map((p) => h("option", { value: p.id }, p.name + " (stock " + p.stock + ")")));
  $("prodCategory").replaceChildren(h("option", { value: "0" }, "No category"),
    ...state.categories.map((c) => h("option", { value: c.id }, c.name)));

  const box = $("adminProducts");
  box.replaceChildren();
  for (const p of products) {
    const input = h("input", { type: "number", min: "0", value: String(p.stock) });
    box.append(h("div", { class: "line" },
      h("div", { class: "grow" }, h("b", {}, p.name), h("div", { class: "muted" }, (p.sku || "no SKU") + " | " + (p.category || "no category") + " | " + money(p.price))),
      input, h("button", { class: "btn small", onclick: async () => {
        const r = await api("/api/admin/stock", "POST", { product_id: p.id, stock: input.value });
        say(r.message, !!r.success); loadAdmin();
      } }, "Save")));
  }
  const ol = $("adminOrders");
  ol.replaceChildren();
  const orders = ords.orders || [];
  if (!orders.length) ol.append(h("p", { class: "muted" }, "No orders yet."));
  for (const o of orders) ol.append(orderBlock(o, true));
}

function formData(form) { return Object.fromEntries(new FormData(form).entries()); }

$("catForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const r = await api("/api/admin/category", "POST", formData(e.target));
  say(r.message, !!r.success);
  if (r.success) { e.target.reset(); await loadCategories(); loadAdmin(); }
});
$("prodForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const r = await api("/api/admin/product", "POST", formData(e.target));
  say(r.message, !!r.success);
  if (r.success) { e.target.reset(); loadAdmin(); }
});

$("demoBtn").addEventListener("click", async () => {
  const out = $("demoOut");
  out.textContent = "Running...";
  const r = await api("/api/admin/demo_race", "POST",
    { product_id: $("demoProduct").value, stock: $("demoStock").value, quantity: $("demoQty").value });
  if (!r.results) { out.textContent = r.message || "Demo failed."; return; }
  out.textContent =
    "Initial stock: " + r.initial_stock + " | each customer tries to buy " + r.quantity_each + "\n" +
    r.results.map((x) => x.customer + ": " + (x.success ? "SUCCESS" : "REJECTED") + " - " + x.message).join("\n") + "\n" +
    "Orders succeeded: " + r.orders_succeeded + " | Final stock: " + r.final_stock +
    " | Never negative: " + (r.never_negative ? "yes" : "NO");
  loadAdmin();
});
$("consBtn").addEventListener("click", async () => {
  const r = await api("/api/admin/consistency");
  $("demoOut").textContent = r.consistent === undefined ? (r.message || "Check failed.")
    : r.consistent ? "Consistent: every product's stock equals the sum of its inventory movements."
      : "INCONSISTENT: " + JSON.stringify(r.mismatches);
});

// ---------- login / register ----------
async function authSubmit(e, path) {
  e.preventDefault();
  const r = await api(path, "POST", formData(e.target));
  if (!r.success) { say(r.message || "Failed.", false); return; }
  state.user = r.user;
  renderUser();
  e.target.reset();
  say("Welcome, " + r.user.name + ".", true);
  if (state.pendingProduct) {
    const pending = state.pendingProduct; state.pendingProduct = null;
    addToCart(pending.product, pending.qty);
    show("bag");
  } else {
    const next = state.pendingView || "shop"; state.pendingView = null; show(next);
  }
}
$("loginForm").addEventListener("submit", (e) => authSubmit(e, "/api/login"));
$("registerForm").addEventListener("submit", (e) => authSubmit(e, "/api/register"));
$("logoutLink").addEventListener("click", async (e) => {
  e.preventDefault();
  await api("/api/logout", "POST");
  state.user = null;
  renderUser();
  say("Logged out.", true);
  show("shop");
});

// ---------- filters ----------
$("searchForm").addEventListener("submit", (e) => { e.preventDefault(); show("shop"); });
$("filters").addEventListener("submit", (e) => { e.preventDefault(); loadProducts(); });
$("fReset").addEventListener("click", () => {
  $("searchBox").value = ""; $("fCategory").value = "0"; $("fMin").value = ""; $("fMax").value = ""; $("fSort").value = "new";
  loadProducts();
});

// ---------- start ----------
(async () => {
  saveCart();
  await Promise.all([loadMe(), loadCategories()]);
  show("shop");
})();
