#!/usr/bin/env bash
set -euo pipefail

echo "AARONI — Admin account setup"
echo "First register your separate admin account on the AARONI website, then log out."
read -r -p "Enter the exact email used for that new account: " ADMIN_EMAIL
if [[ ! "$ADMIN_EMAIL" =~ ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]]; then
  echo "That email format does not look valid. No database changes were made." >&2
  exit 1
fi
ADMIN_EMAIL="${ADMIN_EMAIL,,}"
RESULT=$(sudo mysql --batch --skip-column-names aaroni_c -e "UPDATE users SET role='admin' WHERE email='${ADMIN_EMAIL}'; SELECT CONCAT('MATCHED_ADMIN_ROWS=', ROW_COUNT()); SELECT CONCAT(id, '\t', name, '\t', email, '\t', role) FROM users WHERE email='${ADMIN_EMAIL}';")
printf '%s\n' "$RESULT"
if ! grep -q "${ADMIN_EMAIL}" <<< "$RESULT"; then
  echo "No matching registered account was found. Register that email first; no account was promoted." >&2
  exit 1
fi
echo "\nAdmin role assigned. Log in with this account and open the Admin link."
