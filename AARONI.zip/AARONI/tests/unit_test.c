/* Unit tests for the parts that do not need a database:
 * password hashing, order-item parsing, URL decoding, slugs, JSON escaping.
 * Build and run: make unit */
#include <stdio.h>
#include <string.h>
#include "../src/util.h"
#include "../src/auth.h"
#include "../src/order.h"

static int failures = 0;
#define CHECK(cond, name) do { if (cond) printf("  PASS  %s\n", name); else { printf("  FAIL  %s\n", name); failures++; } } while (0)

int main(void) {
    printf("Password hashing\n");
    const char *seeded = "$6$abcdefghijklmnop$3pm2jX0VbSznjYaMgtxsUnC/HOVhk6SBYQ5G5lJRcYuH9mZ4PCqZAZHKYlVXVZ57RreC7.8QH54XLEM9aIcdi0";
    CHECK(auth_verify("admin123", seeded), "seeded admin hash accepts admin123");
    CHECK(!auth_verify("wrong", seeded), "seeded admin hash rejects a wrong password");
    CHECK(!auth_verify("anything", "!"), "'!' account cannot log in");
    char h1[160], h2[160];
    CHECK(auth_hash("secret123", h1, sizeof h1) == 0 && auth_hash("secret123", h2, sizeof h2) == 0, "auth_hash works");
    CHECK(strcmp(h1, h2) != 0, "same password gets different salts");
    CHECK(auth_verify("secret123", h1) && !auth_verify("secret124", h1), "hash round trip");

    printf("Order item parsing\n");
    Item it[MAX_ITEMS];
    int n = items_parse("5:2,3:1,5:1", it, MAX_ITEMS);
    CHECK(n == 2 && it[0].pid == 3 && it[0].qty == 1 && it[1].pid == 5 && it[1].qty == 3, "merges duplicates and sorts by product id");
    CHECK(items_parse("", it, MAX_ITEMS) == -1, "rejects empty");
    CHECK(items_parse("1:0", it, MAX_ITEMS) == -1, "rejects quantity 0");
    CHECK(items_parse("1:-2", it, MAX_ITEMS) == -1, "rejects negative quantity");
    CHECK(items_parse("abc", it, MAX_ITEMS) == -1, "rejects garbage");
    CHECK(items_parse("1:2x", it, MAX_ITEMS) == -1, "rejects trailing characters");
    CHECK(items_parse("1:101", it, MAX_ITEMS) == -1, "rejects quantity over 100");

    printf("Utilities\n");
    char out[100];
    CHECK(form_get("a=1&name=Jane+Doe%21&z=9", "name", out, sizeof out) && !strcmp(out, "Jane Doe!"), "form_get decodes + and %XX");
    CHECK(!form_get("a=1&b=2", "c", out, sizeof out), "form_get missing key");
    CHECK(form_get("xa=1&a=2", "a", out, sizeof out) && !strcmp(out, "2"), "form_get matches whole key only");
    slugify("Men's  Wear & Co!", out, sizeof out);
    CHECK(!strcmp(out, "men-s-wear-co"), "slugify");
    SB sb; sb_init(&sb);
    sb_json(&sb, "a\"b\\c\n");
    CHECK(!strcmp(sb.p, "\"a\\\"b\\\\c\\u000a\""), "JSON escaping");
    sb_free(&sb);

    printf("\n%s (%d failure%s)\n", failures ? "SOME TESTS FAILED" : "ALL TESTS PASSED", failures, failures == 1 ? "" : "s");
    return failures != 0;
}
