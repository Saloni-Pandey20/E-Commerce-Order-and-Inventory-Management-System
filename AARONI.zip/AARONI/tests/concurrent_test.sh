#!/usr/bin/env bash
# End-to-end concurrency test through the real HTTP API (needs the server + MySQL running).
# Usage: tests/concurrent_test.sh [port]
# Scenario 1: stock 5, customer A and customer B each buy 4 at the same time.
# Scenario 2: stock 5, 20 different customers each buy 1 at the same time (expect exactly 5 successes).
PORT=${1:-8080}; B=http://127.0.0.1:$PORT
T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
RUN=$RANDOM

echo "Logging in as admin and registering test customers..."
curl -s -c $T/admin -X POST -d "email=admin@shop.local&password=admin123" $B/api/login | grep -q '"success":true' || { echo "Admin login failed. Is the server running and sample_data.sql loaded?"; exit 1; }
PID=$(curl -s $B/api/products | grep -o '"id":[0-9]*' | head -1 | cut -d: -f2)
for i in $(seq 0 19); do
  curl -s -c $T/u$i -X POST -d "name=Tester$i&email=t${RUN}_$i@test.local&password=password123" $B/api/register >/dev/null
done

setstock() { curl -s -b $T/admin -X POST -d "product_id=$PID&stock=$1" $B/api/admin/stock >/dev/null; }
stock()    { curl -s $B/api/products | grep -o "\"id\":$PID,[^}]*" | grep -o '"stock":[0-9-]*' | cut -d: -f2; }

echo; echo "== Scenario 1: stock 5, two customers each buy 4 at once (product id $PID) =="
setstock 5
curl -s -b $T/u0 -X POST -d "items=$PID:4" $B/api/checkout > $T/a.json &
curl -s -b $T/u1 -X POST -d "items=$PID:4" $B/api/checkout > $T/b.json &
wait
echo "Customer A: $(cat $T/a.json)"; echo "Customer B: $(cat $T/b.json)"
OK=$(cat $T/a.json $T/b.json | grep -c '"success":true')
echo "Orders succeeded: $OK (expected 1) | Final stock: $(stock) (expected 1)"

echo; echo "== Scenario 2: stock 5, 20 customers each buy 1 at once =="
setstock 5
for i in $(seq 0 19); do curl -s -b $T/u$i -X POST -d "items=$PID:1" $B/api/checkout > $T/r$i.json & done
wait
OK=$(cat $T/r*.json | grep -c '"success":true')
echo "Orders succeeded: $OK (expected 5) | Final stock: $(stock) (expected 0)"

echo; echo "== Consistency check (stock must equal the sum of inventory movements) =="
curl -s -b $T/admin $B/api/admin/consistency; echo
