/* IPC demo: two PROCESSES communicate through a pipe.
 * The parent plays the "order service" and sends order records; the child plays
 * a separate "audit logger" process that receives and prints them.
 * (Processes have separate memory, so they need IPC to share data.)
 * Build: make os_demos     Run: ./os_demos/ipc_pipe */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void) {
    int fd[2];
    if (pipe(fd) < 0) { perror("pipe"); return 1; }
    pid_t pid = fork();
    if (pid < 0) { perror("fork"); return 1; }

    if (pid == 0) {                       /* child: audit logger */
        close(fd[1]);
        char buf[128];
        ssize_t n;
        printf("[logger pid %d] waiting for messages...\n", getpid());
        while ((n = read(fd[0], buf, sizeof buf - 1)) > 0) {
            buf[n] = '\0';
            printf("[logger pid %d] received: %s", getpid(), buf);
        }
        printf("[logger pid %d] pipe closed, exiting\n", getpid());
        close(fd[0]);
        return 0;
    }
    close(fd[0]);                         /* parent: order service */
    printf("[orders pid %d] started logger as pid %d\n", getpid(), pid);
    const char *msgs[] = { "order #1 PLACED total 899.00\n", "order #2 REJECTED insufficient stock\n", "order #3 CANCELLED stock restored\n" };
    for (int i = 0; i < 3; i++) { if (write(fd[1], msgs[i], strlen(msgs[i])) < 0) perror("write"); usleep(200000); }
    close(fd[1]);
    waitpid(pid, NULL, 0);
    printf("[orders pid %d] logger finished\n", getpid());
    return 0;
}
