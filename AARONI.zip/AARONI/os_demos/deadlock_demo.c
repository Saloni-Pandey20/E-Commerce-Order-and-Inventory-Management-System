/* Deadlock demo with two mutexes.
 * Part 1: two threads take the locks in OPPOSITE order -> circular wait (deadlock).
 *         We detect it with a timeout so the program does not hang forever.
 * Part 2: both threads take the locks in the SAME order -> no deadlock.
 * The web app uses the same idea: every checkout locks product rows in ascending
 * id order (src/order.c), and retries if MySQL reports a deadlock (error 1213).
 * Build: make os_demos     Run: ./os_demos/deadlock_demo */
#define _GNU_SOURCE
#include <stdio.h>
#include <pthread.h>
#include <time.h>
#include <unistd.h>

static pthread_mutex_t A = PTHREAD_MUTEX_INITIALIZER, B = PTHREAD_MUTEX_INITIALIZER;

typedef struct { const char *name; pthread_mutex_t *first, *second; int deadlocked; } Arg;

static int lock_timeout(pthread_mutex_t *m, int sec) {
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    ts.tv_sec += sec;
    return pthread_mutex_timedlock(m, &ts);
}

static void *worker(void *p) {
    Arg *a = p;
    pthread_mutex_lock(a->first);
    printf("  %s holds its first lock, wants the second...\n", a->name);
    usleep(300000);                                  /* give the other thread time to grab its lock */
    if (lock_timeout(a->second, 2) != 0) {
        printf("  %s: waited 2s and could not get the second lock -> DEADLOCK detected, releasing\n", a->name);
        a->deadlocked = 1;
    } else {
        printf("  %s got both locks, doing work, releasing\n", a->name);
        pthread_mutex_unlock(a->second);
    }
    pthread_mutex_unlock(a->first);
    return NULL;
}

static void run(const char *title, pthread_mutex_t *t1a, pthread_mutex_t *t1b, pthread_mutex_t *t2a, pthread_mutex_t *t2b) {
    Arg x = { "Thread 1", t1a, t1b, 0 }, y = { "Thread 2", t2a, t2b, 0 };
    pthread_t a, b;
    printf("%s\n", title);
    pthread_create(&a, NULL, worker, &x);
    pthread_create(&b, NULL, worker, &y);
    pthread_join(a, NULL);
    pthread_join(b, NULL);
    printf("  result: %s\n\n", (x.deadlocked || y.deadlocked) ? "deadlock occurred" : "no deadlock");
}

int main(void) {
    run("Part 1: opposite lock order (T1: A then B, T2: B then A)", &A, &B, &B, &A);
    run("Part 2: same lock order (both: A then B)", &A, &B, &A, &B);
    return 0;
}
