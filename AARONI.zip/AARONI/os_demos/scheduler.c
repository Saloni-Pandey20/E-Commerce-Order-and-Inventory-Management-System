/* CPU scheduling demo: FCFS, SJF (non-preemptive) and Round Robin on the same
 * set of "order-processing jobs". Prints a Gantt chart and average times.
 * This is a SIMULATION (it does not change how the web server's threads are
 * scheduled; the Linux kernel does that). Build: make os_demos */
#include <stdio.h>
#include <string.h>

#define N 5
typedef struct { const char *name; int arrival, burst; } Job;
static const Job jobs[N] = {
    {"Order-1", 0, 5}, {"Order-2", 1, 3}, {"Order-3", 2, 8}, {"Order-4", 3, 2}, {"Order-5", 4, 4}
};

static void report(const char *title, const int finish[N]) {
    double wait = 0, turn = 0;
    printf("  %-8s %7s %6s %7s %11s %8s\n", "Job", "Arrive", "Burst", "Finish", "Turnaround", "Waiting");
    for (int i = 0; i < N; i++) {
        int t = finish[i] - jobs[i].arrival, w = t - jobs[i].burst;
        printf("  %-8s %7d %6d %7d %11d %8d\n", jobs[i].name, jobs[i].arrival, jobs[i].burst, finish[i], t, w);
        turn += t; wait += w;
    }
    printf("  %s: average waiting = %.2f, average turnaround = %.2f\n\n", title, wait / N, turn / N);
}

static void fcfs_or_sjf(int sjf) {
    int finish[N], done[N] = {0}, t = 0, left = N;
    printf("%s\n  Gantt: ", sjf ? "SJF (non-preemptive)" : "FCFS (first come, first served)");
    while (left) {
        int pick = -1;
        for (int i = 0; i < N; i++) {
            if (done[i] || jobs[i].arrival > t) continue;
            if (pick < 0 || (sjf ? jobs[i].burst < jobs[pick].burst : jobs[i].arrival < jobs[pick].arrival)) pick = i;
        }
        if (pick < 0) { t++; continue; }
        printf("|%s %d-%d ", jobs[pick].name, t, t + jobs[pick].burst);
        t += jobs[pick].burst; finish[pick] = t; done[pick] = 1; left--;
    }
    printf("|\n");
    report(sjf ? "SJF" : "FCFS", finish);
}

static void round_robin(int q) {
    int rem[N], finish[N], queue[256], head = 0, tail = 0, inq[N] = {0}, t = 0, left = N;
    for (int i = 0; i < N; i++) rem[i] = jobs[i].burst;
    printf("Round Robin (quantum = %d)\n  Gantt: ", q);
    for (int i = 0; i < N; i++) if (jobs[i].arrival <= 0) { queue[tail++] = i; inq[i] = 1; }
    while (left) {
        if (head == tail) { t++; for (int i = 0; i < N; i++) if (!inq[i] && jobs[i].arrival <= t) { queue[tail++] = i; inq[i] = 1; } continue; }
        int j = queue[head++];
        int run = rem[j] < q ? rem[j] : q;
        printf("|%s %d-%d ", jobs[j].name, t, t + run);
        t += run; rem[j] -= run;
        for (int i = 0; i < N; i++) if (!inq[i] && jobs[i].arrival <= t) { queue[tail++] = i; inq[i] = 1; }
        if (rem[j] > 0) queue[tail++] = j; else { finish[j] = t; left--; }
    }
    printf("|\n");
    report("Round Robin", finish);
}

int main(void) {
    fcfs_or_sjf(0);
    fcfs_or_sjf(1);
    round_robin(2);
    return 0;
}
